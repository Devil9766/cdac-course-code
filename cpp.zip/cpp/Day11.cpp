#include <iostream>
using namespace std;
class Demo
{
    public:
    Demo(int xx)
    {
        cout<< xx;
    }
    ~Demo()
    {
        cout<< "Final";
    }
};
int main()
{
   Demo *ptr = new Demo('B');
    return 0;
}
