//code 1: Friend Class
/*
#include <iostream>
using namespace std;
class ramu{
	int emp_id = 20;
	protected : 
	int salary = 20000;
	friend class shamu;
};

class shamu{
	public:
		void display( ramu& i){
			cout<<"employee id and his salary is : "<<i.emp_id<< " , "<<i.salary<<endl;
		}
};

int main(){
	ramu r;
	shamu s;
	s.display(r);
}

*/


//code 2: friend function
//Case 1 :Global friend function
/*
#include<iostream>
using namespace std;

class shamu {
	int a;
	protected:
		int b;
	public:
	shamu(){
		a=10;
		b=20;
	}	
	friend void friendFunction(shamu&);
};
	void friendFunction(shamu& obj){
		cout<<" prev Value of a is "<<obj.a<<" prev of b is "<<obj.b<<endl;
		obj.a=50;
		obj.b=100;
		cout<<" new Value of a is "<<obj.a<<" new of b is "<<obj.b<<endl;
	}
int main(){
	shamu s;
	friendFunction(s);

}
*/

//code 3: Friend Function
//case 2 Member freind function
/*
#include<iostream>
using namespace std;
class car;
class Bmw{
	public:
		void dataLeaker(car&);
};
class car{
	int speed;
	protected :
		int average;
	public: 
	car(){
		speed = 120;
		average = 2;
	}
	friend void Bmw::dataLeaker(car& );
};

void Bmw::dataLeaker(car &i){
	cout<<"prev Speed of BMW is: "<<i.speed<<" and average is: "<<i.average<<endl;
	i.speed= 140;
	i.average = 1;
	cout<<"new Speed of BMW is: "<<i.speed<<" and average is: "<<i.average<<endl;
}
int main(){
	car c;
	Bmw b;
	b.dataLeaker(c);
	return 0;
}

*/

//code 4: 
/*
#include <iostream>    
using namespace std;    
class Box    
{    
    private:    
        int length;    
    public:    
        Box()
	{
		length=5;
	}
        friend int printLength(Box); //friend function    
};    
int printLength(Box t)    
{    
   t.length += 5;    
    return t.length;    
}    
int main()    
{    
    Box b;    
    cout<<"Length of box: "<< printLength(b)<<endl;    
    return 0;    
} 
*/

//code 5: 
/*
#include<iostream>
using namespace std;
class B;
class A{
	int x;
	public:
		void show(int i){
			x=i;
		}
	friend void f(A,B);
};
class B{
	int y;
	public:
		void show(int j){
			y=j;
		}
		
	friend void f(A,B);
};

void f(A a, B b){
	if(a.x<=b.y){
		cout<<a.x<<endl;
	}else{
		cout<<b.y<<endl;
	}
}

int main(){
	A a;
	B b;
	a.show(10);
	b.show(20);
	f(a,b);
}

*/

//code 
