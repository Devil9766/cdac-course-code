//code 1 
/*
#include <iostream>
using namespace std;
class A{
	int a;
	public:
		virtual void show(){
			cout<<"base class show function called."<<endl;
			
		}
};

class B : public A{
	int b;
	public:
		void show(){
			cout<<"derieved class show function called."<<endl;
		}
};

int main(){
	A *ptr = new B();
	ptr->show();
	}
	*/
	
	//code 2 : 
	/*
	#include<iostream>
	using namespace std;
	
	class grandParents{
		public:
		virtual void func1(){
			cout<<"Grand func1 calling"<<endl;
		}
		 virtual void func2(){
			cout<<"grand func2 calling\n";
		}
		virtual void func3(){
			cout<<"grand func3 calling \n";
		}
	};
	class parents : public grandParents{
		public:
			void func1(){
				cout<<"parent func1 calling \n";
			}
			void func3(){
				cout<<"parent func3 calling \n";
			}
	};
	class child : public parents{
		public:
			void func2(){
				cout<<"child func2 calling \n";
			}
	};
	
	int main(){
		grandParents *ptr1 = new grandParents();
		grandParents *ptr2 = new parents();
		grandParents *ptr3 = new child();
		
		ptr1->func1(); 
	    ptr1->func2(); 
	    ptr1->func3(); 
	    ptr2->func1(); 
	    ptr2->func2(); 
	    ptr2->func3(); 
	    ptr3->func1(); 
	    ptr3->func2(); 
	    ptr3->func3();
	    
	    delete ptr1; 
	    delete ptr2; 
	    delete ptr3; 
	}
	*/
	
	//code 3 : Multiple inheritance
	/*
	#include <iostream>
	using namespace std;
	class vehicle{
		public:
			vehicle(){
				cout<<" vehicle constructor called.\n";
			}
			~vehicle(){
				cout<<" vehicle desconstructor called.\n";
			}
	};
	
	class car {
		public:
			car(){
				cout<<" car constructor called.\n";
			}
			~car(){
				cout<<" car desconstructor called.\n";
			}
	};
	
	class bmw : public vehicle , public car{
		public:
			bmw(){
				cout<<"bmw constructor called.\n";
			}
			~bmw(){
				cout<<"bmw desconstructor called.\n";
			}
	};
	
	int main(){
		bmw obj ;
		return 0;
	}
	*/
	
	//code 4 : 
	/*
	#include <iostream>
	using namespace std;
	class vehicle{
		public:
			vehicle(){
				cout<<" vehicle constructor called.\n";
			}
			vehicle(int b){
				cout<<" vehicle paraconstructor called.\n";
			}
	};
	
	class car {
		public:
			car(){
				cout<<" car constructor called.\n";
			}
			car(int a){
				cout<<" car paraconstructor called.\n";
			}
	};
	
	class bmw : public vehicle , public car{
		public:
			bmw(){
				cout<<"bmw constructor called.\n";
			}
			bmw(int p, int q): car(p) , vehicle(){
				cout<<"bmw paraconstructor called.\n";
			}
	};
	
	int main(){
		bmw obj(10 , 30) ;
		return 0;
	}
	
	*/
	
	//code 5:
	/*
#include <iostream>
using namespace std;
class A{
	int a;
	public:
		void show(){
			cout<<"base class show function called."<<endl;
			
		}
};

class B {
	int b;
	public:
		void show(){
			cout<<"derieved class show function called."<<endl;
		}
};
class C: public B , public A{
	public:
	 void dis(){
	 	cout<<"c display. \n";
	 }
};

int main(){
	C obj1;
	obj1.A::show();
	}
*/

//code 6 : Diamond inheritance
/*
#include <iostream>
using namespace std;

class shape{
	public:
		shape(int x){
			cout<<"shape para"<<endl;
		}
};	
class triangle1 : public shape{
	public:
	triangle1(int a): shape(a){
		cout<<"traingle1 para\n";
	}
};
class triangle2 : public shape{
	public:
	triangle2(int b):shape(b){
		cout<<"traingle2 para\n";
	}
};
class rhombus : public triangle1, public triangle2{
	public:
	rhombus(int p, int q) : triangle1(p),triangle2(q){
		cout<<"rhombus para\n";
	}
};

int main(){
	rhombus obj(10,20);
	return 0;
} 

*/

//code 7 : 

#include <iostream>
using namespace std;

class shape{
	public:
		shape(){
			cout<<"shape const"<<endl;
		}
		shape(int x){
			cout<<"shape para"<<endl;
		}
		void show(){
			cout<<"shape function called"<<endl;
		}
};	
class triangle1 :  public shape{
	public:
		triangle1(){
		cout<<"traingle1 const\n";
		}
		triangle1(int a): shape(a){
			cout<<"traingle1 para\n";
		}
};
class triangle2 : virtual public shape{
	public:
	triangle2(){
		cout<<"traingle2 const\n";
	}
	triangle2(int b):shape(b){
		cout<<"traingle2 para\n";
	}
};
class rhombus : public triangle1, public triangle2{
	public:
	rhombus(){
		cout<<"rhombus const"<<endl;
	}
	rhombus(int p, int q) : triangle1(p),triangle2(){
		cout<<"rhombus para\n";
	}
};

int main(){
	rhombus obj(10,20);
	obj.triangle2::show();
	return 0;
} 
