//code 1
/*#include<iostream>
using namespace std;


class area{
	protected:
		int rad;
		
};
class circle : private area{
	public:
	void show(){
		cout<<"enter radius"<<endl;
		cin>>rad;
		cout<<"area is : "<<3.14*rad*rad;
	}
};

int main(){
	circle obj;
	obj.show();
}*/


//Code 2
/*
#include<iostream>
using namespace std;
class shape{
	int a ,b;
	public:
		shape(){
			cout<<"default constructor of a."<<endl;
			a = 30;
			b = 10;
		}
		void display(){
			cout<<"value of a is: "<<a<<endl;
			cout<<"value of b is: "<<b<<endl;
		}
};
class circle : public shape{
	int c ;
	public:
		circle(){
			cout<<"default constructor of circle."<<endl;
			c = 20;
		}
		void show(){
			shape::display();
			cout<<"value of c is: "<<c<<endl;
			
		}
};

int main(){
	circle obj;
	obj.show();
}
*/

//code 2:
/*
#include<iostream>
using namespace std;

class A{
	int a;
	public :
		A(){
			cout<<" default A"<<endl;
			a=10;
			
		}
		void show(){
			cout<<"value of a "<<a<<endl;
		}
};
class B : public A{
	int b;
	public :
		B(int p, int q) {
			cout<<" default B"<<endl;
			b=q;
		}
		void dis(){
			show();
			cout<<"value of b "<<b<<endl;
		}
};
int main(){
	B obj(20,30);
	obj.dis();
}
*/

//code 3:
/*
#include<iostream>
using namespace std;

class A{
	int a;
	public :
		A(int p){
			cout<<" default A"<<endl;
			a=p;
			
		}
		void show(){
			cout<<"value of a "<<a<<endl;
		}
};
class B : public A{
	int b;
	public :
		B(int p, int q): A(p) {
			cout<<" default B"<<endl;
			b=q;
		}
		void dis(){
			show();
			cout<<"value of b "<<b<<endl;
		}
};
int main(){
	B obj(20,30);
	obj.dis();
}

*/

//code 4:


#include<iostream>
using namespace std;

int main(){
	
}

