//assignment :
/*
#include<iostream>
using namespace std;
#include<cstdio>
#include<cstring>
int main(){
	static int count,space_cnt,vowels,words,ch_cnt;
	char ch;
	char str[100] ;
	cout<<"enter string: "<<endl;
    cin.getline( str,100);
    int i;
    for(i=0;i<strlen(str);i++){
    	count++;
    	if(str[i]=='a'||str[i]=='e'||str[i]=='i'||str[i]=='o'||str[i]=='u'){
    		vowels++;
		}
    	if(str[i]==' '){
    		space_cnt++;
    		words++;
    		count--;
		}
		
	}
	cout<<count<<" "<<space_cnt<<" "<<vowels<<" "<<words+1<<endl;
//    puts(  string);
    
}



// code 
/*
#include<iostream>
#include<string.h>
using namespace std;
void concat(char *  , char* );
int main(){
	
	char str1[100] , str2[100];
	cout<<"enter string 1: ";
	cin>>str1;
	cout<<"enter string 2: ";
	cin>>str2;
	concat(str1 , str2  );
	cout<<str1;
}
void concat(char * s , char* t){
	while(*s!= '\0'){
		s++;
	}
	while(*t!='\0'){
		*s = *t;
		s++;
		t++;
	}
	*s = '\0';
	
}
*/

//code

#include <iostream>
using namespace std;
template <class T,class S> 
T myMax(T x, S y)
{
	
    std::cout << "Value of a is : " <<x<< std::endl;  
    std::cout << "Value of b is : " <<y<< std::endl;  
    return x+y;
}
 
int main()
{
    // Call myMax for int
    cout << myMax<float>(3, 7.2) << endl;
    // call myMax for double
    cout << myMax<int>(3.5, 7.0) << endl;
    // call myMax for char
    cout << myMax<int>('g', 'e') << endl;
    return 0;
}


//code 
/*
#include<iostream>
using namespace std;
 
template<class T> class A{
	public:
		
		T arr[10];
	
	
	void show(){
		int i =1;  
        for (int j=0;j<5;j++)  
        {  
            arr[j] = i;  
            i++;  
        }  
	for(int i=0;i<5;i++)  
        {  
            std::cout << arr[i] << " ";  
        } 
		
	}
};
int main(){
	A <int > obj;
	obj.show();
}*/
