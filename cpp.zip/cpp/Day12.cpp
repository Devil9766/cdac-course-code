//Assignment 1
/*
#include<iostream>
using namespace std;
int a, b;
void swap(int a,int b){
	a=a+b;
	b=a-b;
	a=a-b;
	cout<<a<< " "<<b;
}
int main(){
	a= 5; b= 6;
	swap(a,b);
}
*/
//Assignment 2
/*
#include<iostream>
#include<string.h>
using namespace std;

int main(){
	int num, rem, original_num, reversed_num = 0 ;
	cout<<"write a number : ";
	cin>>num;
	original_num = num;
	while(num!=0){
		rem=num%10;
		reversed_num = reversed_num * 10 + rem;
		num = num/10;
		
	}
	if(original_num == reversed_num){
		cout<<"number is palindrome.";
	}
	else{
		cout<<"number is not palindrome.";
	}
	
}

*/

//assignment 3: 
/*
#include <iostream>
using namespace std;

int main(){
	int i = 1;
	int num,count ;
	
	cout<<"enter an number : "<<endl;
	cin>>num;
	while(count< num){
		while(i>0){
			if(i%2 !=0 || i%3!=0){
				cout<<i;
				i++;
			}
			count++;
			
		}
	}
}

*/
//Assignment 4:
/*
#include<iostream>
using namespace std;

int main(){
	int fact=1;
	for(int i=5;i<=8;i++){
		fact=1;
	
		for(int j=i;j>0;j--){
			fact =fact*j;
		}
		cout<<fact<<endl;
	}
}

*/

//assignment 5
/*
#include<iostream>
using namespace std;
int main(){
	int even_sum = 0 ;
	int odd_sum = 0 ;
	int arr[10] = {1,2,3,4,5,6,7,8,9,10};
	for (int i =0 ; i< (sizeof(arr)/sizeof(arr[0]) ); i++){
		if(arr[i]% 2 == 0){
			even_sum += arr[i];
		}
		else{
			odd_sum += arr[i];
		}
	}
	cout<<"sum of even is: "<<even_sum<< " and sum of odd is: "<<odd_sum<<endl;
}
*/
//assignment 6
/*
#include<iostream>
using namespace std;
#include<string.h>
int main(){
	char* str = new char[10];
	char * change_str = new char[ 10];
	cout<<"Enter string : ";
	cin>>str;
	for(int i=0;i<strlen(str);i++){
		if( str[i] > 94){
			change_str[i] = str[i] - 32; 
		}else{
			change_str[i] = str[i] + 32; 
		}
	}
	cout<<change_str;
	
	
}
*/
//assignment 7: 
/*
#include<iostream>
using namespace std;
template <class T>
T swap( T a , T b){
	T temp ;
	temp = a;
	a = b;
	b = temp;
	cout << a <<" " <<b;
}
int main(){

	swap('A', 'B');
}

*/

//assignment 8 : 
/*
#include<iostream>
using namespace std;

int main(){
	int x,cnt;
	cout<<"Enter number : \n";
	cin>>x;
	while(x!=0){
//		x = x%10;
		x=x/10;
		cnt++;
	}
	cout<<"No. of digits are : "<<cnt;
}
*/


//assignment no 9 
/*
#include<iostream>
using namespace std;
int main(){
	
	int num, rem, revnum = 0 ;
		cout<<"write a number : ";
		cin>>num;
		while(num!=0){
			rem=num%10;
			revnum = revnum * 10 + rem;
			num = num/10;
			
		}
		
		cout<<"Reversed number is : "<<revnum;
	}
*/


//assignment no 10: 
/*
#include<iostream>
#include<string.h>
using namespace std;
int main(){
	int j=0;
	char*  ch =new char[100];
	char* newch = new char[100]; 
	cout<<"enter string : "<<endl;
	cin.getline(ch, 100);
	
	for(int i=0;i<strlen(ch);i++){
		if((ch[i]>=65&& ch[i]<=90) || (ch[i]>=97 && ch[i]<=122) || ch[i]== 32){
			newch[j++]=ch[i];
		}
		
	}
	cout<<newch;
}
*/

