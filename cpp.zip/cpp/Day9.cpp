//code 3
/*
#include <iostream>
using namespace std;
class Player
{
private:
    static int id;
    static int next_id;
public:
    int getID() { cout <<" "<<endl;return id; }
    Player()  {  id = next_id++; cout<< next_id<<endl;}
};

int Player::next_id = 0;
int Player::id = 0;
int main()
{
  Player p1;
  cout << p1.getID() << " ";
  Player p2;
  cout << p2.getID() << " ";
  Player p3;
  cout << p3.getID();
  return 0;
}

*/

//code 1 operator overloading (+)

#include<iostream>
using namespace std;

class loan{
	int money, int_money;
	public:
		loan(){
			money=int_money= 0;
		}
		loan(int m , int n){
			this->money = m;
			this->int_money = n;	
		}
		loan operator+(loan& a){
			loan temp;
			temp.money = this->money + a.money;
			temp.int_money = this->int_money + a.int_money;
			return temp;
		};
		loan operator-(loan& b){
			loan temp;
			temp.money = this->money - b.money;
			temp.int_money = this->int_money - b.int_money;
			return temp;
		};
		void show(){
			cout<<"money is : "<< money<<" and interest money is : "<<int_money<<endl; 
		};
	
};
int main(){
	loan c1(5000, 6000);
	loan c2(7000, 8000);
	loan c3 = c1 + c2;
	c3.show();
}


//code
/*
#include<iostream>
using namespace std;

int main(){
	char* ch[5] = {"ram", "shyam", "baburao", "hrishi"};
	for(int i=0;i<=4;i++){
		for(int j=0;j<=4;j++){
				cout<<ch[i][j]<<endl;
		}
	
		
	}
}

*/

//code

//Excercise 5:

 
