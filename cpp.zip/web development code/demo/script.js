document.onload(alert("Welcome To Iet"));
function alertIet(){
    alert("Welcome to IET")
}

window.document.write("Apple", "Grape");
	  document.writeln("Mango", "Banana");
	  window.console.log("Orange");
	  console.log("invalid data");