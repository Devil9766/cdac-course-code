const http = require("http");
const prime = require('./methodJs/prime')
const server = http.createServer((req,res)=>{
    var x=10;
   var bool= prime.prime(x);
   if(bool===true){
    res.write(`${x} is a prime number`)
   }else{
    res.write(`${x} is not a prime number`)
   }
   res.end();
});

server.listen(3000,()=>{
    console.log('server is started');
})