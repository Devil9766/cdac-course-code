import React from "react";

export function Navigation(props){
    return(
        <div className="Navigation">
             <div className="webTitle">
                <img src="" alt="" />
                <h1>Assignment</h1>
             </div>
        </div>
    )
}