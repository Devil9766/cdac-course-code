import { useState } from 'react'

import './App.css'
import { Navigation } from './components/navigation'
import { Count } from './count'
function App() {
  const [count, setCount] = useState(0)

  return (
    <div className='space'>
      <Navigation />
      <h2>{count}</h2>
      <br />
      <button onClick={()=> setCount((count)=> count + 4)}>+</button><button onClick={()=> setCount((count)=> count - 1)}>-</button>
      <br />
      <Count />
    </div>
  )
}

export default App
