import { Component } from "react";

export class Count extends Component{
    constructor(props){
        super(props)
        this.state = { cnt : 0}  
        
    }
    

    render(){
        const inc = ()=>{
            this.setState((prev)=>({
               cnt: prev.cnt+1
            }))
            } 
        const dec = ()=>{
            this.setState((prev)=>({
                cnt :prev.cnt -1
            }))
            } 
        return(
            <div>
                {this.state.cnt}
                <br />
                <button onClick={inc}>+</button><button onClick={dec}>-</button>
            </div>
        )
    }
}