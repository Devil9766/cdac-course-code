//rename
// const fs = require('fs');
// fs.rename('text.txt','text1.txt',(error)=>{
//     if(error){
//         console.log(error);
//     }else{
//         console.log("file renamed successfully");
//     }
// })

//delete
// const fs = require('fs');
// fs.unlink('text1.txt',(error)=>{
//     if(error){console.log(error);}
//     else{
//         console.log("deleted successfully");
//     }
// })
