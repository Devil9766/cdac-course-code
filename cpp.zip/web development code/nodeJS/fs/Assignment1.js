//write file 

const fs = require('fs');
fs.writeFile("text.txt","asdhgfsdakf asdhfsfbh asdf iuags f",(error)=>{
    if(error){
        console.log(error);
    }else{
        console.log("data saved successfully");
    }
})