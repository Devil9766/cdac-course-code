const fs = require("fs");
fs.open("text2.txt" , 'w' , (error , file)=>{
    if(error){
        console.log(error);
    }else{
        console.log("file created");
        console.log(file);
    }
})