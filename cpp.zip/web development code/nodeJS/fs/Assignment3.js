const fs = require('fs');
fs.appendFile("text.txt","hasgdf hsagdf hasd fjh\n",(error)=>{
    if(error){
        console.log(error);
    }else{
        console.log("Pasted successfully");
    }
})
