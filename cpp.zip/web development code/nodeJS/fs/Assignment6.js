const fs=require('fs');
console.log("before reading file");
const data=fs.readFileSync('text2.txt');//it will return the value 
console.log(data);
console.log(data.toString());
console.log("after reading file");