const http = require("http");
const PORT = 3000;

const server = http.createServer((req,res)=>{
    for(i=5;i<=10;i++){
        var fact =1;    
        for(j = i; j>=1 ; j--){
            fact *=j;
        }
    res.write(`factorial of ${i} is ${fact} \n`);
}
    
    res.end();
});
server.listen(3000 , ()=>{
    console.log(`Server started on port ${PORT}`);
})