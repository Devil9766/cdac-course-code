const http = require('http');
const Port = 3000;
const Server = http.createServer((req,res)=>{
    var a = 10;
    var b = 30
    res.write(`sum is ${a+b}`);
    res.end();
});
Server.listen(Port , ()=>{
    console.log(`Server stated successfully on port ${Port}`);
});



