drop PROCEDURE if exists insertVal;
delimiter $
create PROCEDURE insertVal(in tName varchar(64),in value varchar(1000))
BEGIN
	set @insertQ= concat('insert into ',tName ,' VALUES','(',value,')');
	prepare q1 from @insertQ ;
	EXECUTE q1;
	
END $
delimiter ;
