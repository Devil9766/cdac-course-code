drop PROCEDURE if EXISTS pro;
delimiter $
create PROCEDURE pro()
BEGIN
	DECLARE x int DEFAULT 1;
	l:loop 
		if x<=10 THEN
			SELECT x;
			set x:= x+1;
		else 
			leave l;
		end if;
	end loop l;
end$

delimiter ;