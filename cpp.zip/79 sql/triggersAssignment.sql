/*drop trigger if  exists t1;
delimiter $
create trigger t1 before update on emp for each ROW
begin
	insert into bu1 values(old.empno,old.ename,old.job,now(),user());
	
end $

create trigger t2 after update on emp for each ROW
begin
	insert into bu1 values(old.empno,old.ename,new.job,now(),user());
	
end $
delimiter ;
 */
 
 
 
 /* Assignment 1    
 
 DROP TRIGGER IF EXISTS insertStudent;
 DELIMITER $
 CREATE TRIGGER insertStudent AFTER update on student for each row
 begin 
	insert into log values(now(),now(),"Record inserted successfully");
end $
delimiter ;
 
*/

/*Assignment 2 

drop trigger if  exists t3;

delimiter $
create trigger t3 after insert on student for each ROW
begin
	insert into student_log values(new.id, new.namefirst, new.namelast, new.dob, new.emailid);
end $
delimiter ;

*/


/*Assignment 3 


drop trigger if  exists t3;

delimiter $
create trigger t3 after update on student for each ROW
begin
	insert into student_log values(old.id, old.namefirst, old.namelast, old.dob, new.emailid);
end $
delimiter ;

*/


/*Assignment 4*/

drop trigger if  exists t3;

delimiter $
create trigger t3 before delete on student for each ROW
begin
	insert into student_log values(old.id, old.namefirst, old.namelast, old.dob, old.emailid);
end $
delimiter ;