drop PROCEDURE if exists pro;
delimiter $
create PROCEDURE pro(in tName varchar(64),in cName VARCHAR(1000))
BEGIN
	set @q= concat('CREATE TABLE ',tName,'(',cName, ')');
	prepare q1 from @q ;
	EXECUTE q1;
	
END $
delimiter ;


	