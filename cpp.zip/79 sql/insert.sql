-- Insert data into Course table
INSERT INTO Course (id, name, duration, summary) VALUES (1, 'Mathematics', '3 months', 'Basic Mathematics course');
INSERT INTO Course (id, name, duration, summary) VALUES (2, 'Physics', '4 months', 'Advanced Physics course');
INSERT INTO Course (id, name, duration, summary) VALUES (3, 'Chemistry', '3 months', 'Introductory Chemistry course');
INSERT INTO Course (id, name, duration, summary) VALUES (4, 'Biology', '4 months', 'Biology course for beginners');
INSERT INTO Course (id, name, duration, summary) VALUES (5, 'Computer Science', '6 months', 'Comprehensive Computer Science course');

-- Insert data into Student table
INSERT INTO Student (id, namefirst, namelast, dob, emailid) VALUES (1, 'John', 'Doe', '2000-01-01', 'john.doe@example.com');
INSERT INTO Student (id, namefirst, namelast, dob, emailid) VALUES (2, 'Jane', 'Smith', '1999-05-15', 'jane.smith@example.com');
INSERT INTO Student (id, namefirst, namelast, dob, emailid) VALUES (3, 'Alice', 'Johnson', '2001-07-22', 'alice.johnson@example.com');
INSERT INTO Student (id, namefirst, namelast, dob, emailid) VALUES (4, 'Bob', 'Brown', '1998-11-30', 'bob.brown@example.com');
INSERT INTO Student (id, namefirst, namelast, dob, emailid) VALUES (5, 'Charlie', 'Davis', '2002-03-10', 'charlie.davis@example.com');

-- Insert data into Student_Phone table
INSERT INTO Student_Phone (id, studentId, number, isActive) VALUES (1, 1, '1234567890', TRUE);
INSERT INTO Student_Phone (id, studentId, number, isActive) VALUES (2, 2, '2345678901', TRUE);
INSERT INTO Student_Phone (id, studentId, number, isActive) VALUES (3, 3, '3456789012', FALSE);
INSERT INTO Student_Phone (id, studentId, number, isActive) VALUES (4, 4, '4567890123', TRUE);
INSERT INTO Student_Phone (id, studentId, number, isActive) VALUES (5, 5, '5678901234', FALSE);

-- Insert data into Student_Address table
INSERT INTO Student_Address (id, studentID, address) VALUES (1, 1, '123 Main St');
INSERT INTO Student_Address (id, studentID, address) VALUES (2, 2, '456 Elm St');
INSERT INTO Student_Address (id, studentID, address) VALUES (3, 3, '789 Maple Ave');
INSERT INTO Student_Address (id, studentID, address) VALUES (4, 4, '101 Oak St');
INSERT INTO Student_Address (id, studentID, address) VALUES (5, 5, '202 Pine St');

-- Insert data into Faculty table
INSERT INTO Faculty (id, namefirst, namelast, DOB, emailID) VALUES (1, 'Dr. Emily', 'Clark', '1980-02-20', 'emily.clark@university.edu');
INSERT INTO Faculty (id, namefirst, namelast, DOB, emailID) VALUES (2, 'Dr. Michael', 'Harris', '1975-06-15', 'michael.harris@university.edu');
INSERT INTO Faculty (id, namefirst, namelast, DOB, emailID) VALUES (3, 'Dr. Sarah', 'Lewis', '1982-09-10', 'sarah.lewis@university.edu');
INSERT INTO Faculty (id, namefirst, namelast, DOB, emailID) VALUES (4, 'Dr. David', 'Walker', '1978-12-05', 'david.walker@university.edu');
INSERT INTO Faculty (id, namefirst, namelast, DOB, emailID) VALUES (5, 'Dr. Linda', 'Martinez', '1985-03-25', 'linda.martinez@university.edu');




-- Insert data into Faculty_Phone table
INSERT INTO Faculty_Phone (id, facultyId, number) VALUES (1, 1, '9876543210');
INSERT INTO Faculty_Phone (id, facultyId, number) VALUES (2, 2, '8765432109');
INSERT INTO Faculty_Phone (id, facultyId, number) VALUES (3, 3, '7654321098');
INSERT INTO Faculty_Phone (id, facultyId, number) VALUES (4, 4, '6543210987');
INSERT INTO Faculty_Phone (id, facultyId, number) VALUES (5, 5, '5432109876');

-- Insert data into Faculty_Address table
INSERT INTO Faculty_Address (id, facultyId, address) VALUES (1, 1, '321 Main St');
INSERT INTO Faculty_Address (id, facultyId, address) VALUES (2, 2, '654 Elm St');
INSERT INTO Faculty_Address (id, facultyId, address) VALUES (3, 3, '987 Maple Ave');
INSERT INTO Faculty_Address (id, facultyId, address) VALUES (4, 4, '110 Oak St');
INSERT INTO Faculty_Address (id, facultyId, address) VALUES (5, 5, '203 Pine St');

-- Insert data into Modules table
INSERT INTO Modules (id, name, duration) VALUES (1, 'Algebra', 30);
INSERT INTO Modules (id, name, duration) VALUES (2, 'Thermodynamics', 45);
INSERT INTO Modules (id, name, duration) VALUES (3, 'Organic Chemistry', 40);
INSERT INTO Modules (id, name, duration) VALUES (4, 'Genetics', 35);
INSERT INTO Modules (id, name, duration) VALUES (5, 'Programming Basics', 50);

-- Insert data into Course_Modules table
INSERT INTO Course_Modules (id, courseID, moduleID) VALUES (1, 1, 1);
INSERT INTO Course_Modules (id, courseID, moduleID) VALUES (2, 2, 2);
INSERT INTO Course_Modules (id, courseID, moduleID) VALUES (3, 3, 3);
INSERT INTO Course_Modules (id, courseID, moduleID) VALUES (4, 4, 4);
INSERT INTO Course_Modules (id, courseID, moduleID) VALUES (5, 5, 5);

-- Insert data into Student_Qualification table
INSERT INTO Student_Qualification (id, studentID, name, college, university, marks, year) VALUES (1, 1, 'High School Diploma', 'Central High', 'State University', '85%', 2018);
INSERT INTO Student_Qualification (id, studentID, name, college, university, marks, year) VALUES (2, 2, 'Associate Degree', 'Community College', 'State University', '90%', 2019);
INSERT INTO Student_Qualification (id, studentID, name, college, university, marks, year) VALUES (3, 3, 'Bachelor of Science', 'Tech College', 'Tech University', '88%', 2020);
INSERT INTO Student_Qualification (id, studentID, name, college, university, marks, year) VALUES (4, 4, 'Bachelor of Arts', 'Arts College', 'Arts University', '92%', 2019);
INSERT INTO Student_Qualification (id, studentID, name, college, university, marks, year) VALUES (5, 5, 'Diploma in IT', 'IT Institute', 'Tech University', '87%', 2021);

-- Insert data into Faculty_Qualification table
INSERT INTO Faculty_Qualification (id, facultyID, name, college, university, marks, year) VALUES (1, 1, 'PhD in Mathematics', 'Mathematics College', 'Science University', '95%', 2010);
INSERT INTO Faculty_Qualification (id, facultyID, name, college, university, marks, year) VALUES (2, 2, 'PhD in Physics', 'Physics College', 'Science University', '97%', 2008);
INSERT INTO Faculty_Qualification (id, facultyID, name, college, university, marks, year) VALUES (3, 3, 'PhD in Chemistry', 'Chemistry College', 'Science University', '96%', 2012);
INSERT INTO Faculty_Qualification (id, facultyID, name, college, university, marks, year) VALUES (4, 4, 'PhD in Biology', 'Biology College', 'Science University', '94%', 2011);
INSERT INTO Faculty_Qualification (id, facultyID, name, college, university, marks, year) VALUES (5, 5, 'PhD in Computer Science', 'Computer Science College', 'Tech University', '98%', 2013);

-- Insert data into Course_Batches table
INSERT INTO Course_Batches (id, name, courseID, starton, endson, capacity) VALUES (1, 'Batch A', 1, '2023-01-15', '2023-04-15', 30);
INSERT INTO Course_Batches (id, name, courseID, starton, endson, capacity) VALUES (2, 'Batch B', 2, '2023-02-01', '2023-06-01', 25);
INSERT INTO Course_Batches (id, name, courseID, starton, endson, capacity) VALUES (3, 'Batch C', 3, '2023-03-10', '2023-06-10', 20);
INSERT INTO Course_Batches (id, name, courseID, starton, endson, capacity) VALUES (4, 'Batch D', 4, '2023-04-05', '2023-08-05', 15);
INSERT INTO Course_Batches (id, name, courseID, starton, endson, capacity) VALUES (5, 'Batch E', 5, '2023-05-20', '2023-11-20', 40);

-- Insert data into Batch_Students table
INSERT INTO Batch_Students (id, batchId, studentId) VALUES (1, 1, 1);
INSERT INTO Batch_Students (id, batchId, studentId) VALUES (2, 2, 2);
INSERT INTO Batch_Students (id, batchId, studentId) VALUES (3, 3, 3);
INSERT INTO Batch_Students (id, batchId, studentId) VALUES (4, 4, 4);
INSERT INTO Batch_Students (id, batchId, studentId) VALUES (5, 5, 5);

-- Insert data into Student_Cards table
INSERT INTO Student_Cards (id, studentId, name, isActive) VALUES (1, 1, 'John Doe', TRUE);
INSERT INTO Student_Cards (id, studentId, name, isActive) VALUES (2, 2, 'Jane Smith', TRUE);
INSERT INTO Student_Cards (id, studentId, name, isActive) VALUES (3, 3, 'Alice Johnson', FALSE);
INSERT INTO Student_Cards (id, studentId, name, isActive) VALUES (4, 4, 'Bob Brown', TRUE);
INSERT INTO Student_Cards (id, studentId, name, isActive) VALUES (5, 5, 'Charlie Davis', FALSE);

-- Insert data into Student_Order table
INSERT INTO Student_Order (id, studentId, date, amount) VALUES (1, 1, '2023-01-20', 100);
INSERT INTO Student_Order (id, studentId, date, amount) VALUES (2, 2, '2023-02-15', 150);
INSERT INTO Student_Order (id, studentId, date, amount) VALUES (3, 3, '2023-03-25', 200);
INSERT INTO Student_Order (id, studentId, date, amount) VALUES (4, 4, '2023-04-10', 250);
INSERT INTO Student_Order (id, studentId, date, amount) VALUES (5, 5, '2023-05-05', 300);