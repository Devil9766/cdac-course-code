package com.demo.service;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.demo.beans.Course;
import com.demo.dao.MapDao;
import com.demo.dao.MapDaoImpl;

public class MapServiceImpl implements MapService {
	private MapDao dao ;
	
	public MapServiceImpl() {
		super();
		dao = new MapDaoImpl();
	}

	@Override
	public boolean addCourse() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter course name");
		String nm=sc.next();
		System.out.println("capacity");
		int intake=sc.nextInt();
		System.out.println("enter fees");
		double fees=sc.nextDouble();
		System.out.println("Enter duration");
		int duration=sc.nextInt();
		Course c = new Course(nm, intake, intake, duration);
		return dao.createCourse(c);
		
	}

	@Override
	public Map<String, Course> getAll() {
		return dao.getAll();
	}

	@Override
	public Map<String, Course> getByName(String cname) {
		
		return dao.getByName(cname);
	}

	@Override
	public boolean updateCourse(String nm, int intake, int fees, int dur) {
		return dao.updateCourse(nm , intake, fees , dur);
	}

	@Override
	public boolean deleteCourse(String nm) {
		
		return dao.deleteCourse(nm);
	}

	@Override
	public Map<String, Course> getByDur(int duration) {
		return dao.getByDur(duration);
	}

	@Override
	public Map<String, Course> sortByName() {
		return dao.sortByName();
	}

	@Override
	public List< Course> sortByDur() {
		return dao.sortByDur();
	}

}
