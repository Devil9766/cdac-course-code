package com.demo.service;

import java.util.List;
import java.util.Map;

import com.demo.beans.Course;

public interface MapService {

	boolean addCourse();

	Map<String, Course> getAll();

	Map<String, Course> getByName(String cname);

	boolean updateCourse(String nm, int intake, int fees, int dur);

	boolean deleteCourse(String nm);

	Map<String, Course> getByDur(int duration);

	
	Map<String, Course> sortByName();

	List<Course> sortByDur();

}
