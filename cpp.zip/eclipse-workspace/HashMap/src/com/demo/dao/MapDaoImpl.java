package com.demo.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import com.demo.beans.Course;

public class MapDaoImpl implements MapDao {
	static Map<String, Course> map ;
	static {
		map=new HashMap<>();
		map.put("DAC", new Course("DAC",200,35000,120));
		map.put("DBDA", new Course("DBDA",100,25000,150));
	}
	@Override
	public boolean createCourse(Course c) {
		Course c1 = map.putIfAbsent(c.getCourseName(), c);
		if(c1==null) {
			return true;
		}
		return false;
	}
	@Override
	public Map<String, Course> getAll() {
		return map; 
	}
	@Override
	public Map<String, Course> getByName(String cname) {
		Map<String, Course> m1 = new HashMap<String, Course>();
		for(Map.Entry<String, Course> e : map.entrySet()) {
			if(e.getKey().equals(cname)) {
				m1.put(e.getKey(), e.getValue());
			}
			
		}
		return m1;
	}
	@Override
	public boolean updateCourse(String nm, int intake, int fees, int dur) {
		for(Map.Entry<String, Course> e : map.entrySet()) {
			if(e.getValue().getCourseName().equals(nm)) {
				e.getValue().setIntake(intake);
				e.getValue().setFees(fees);
				e.getValue().setDuration(dur);
				return true;
			}
		}return false;
	}
	@Override
	public boolean deleteCourse(String nm) {
		
		Course c = map.remove(nm);
				if(c!= null) {
					return true;
				}else {
					return false;
				}
				}
	@Override
	public Map<String, Course> getByDur(int duration) {
		Map<String, Course> m1 = new HashMap<String, Course>();
		for(Map.Entry<String,Course> e : map.entrySet()) {
			if(e.getValue().getDuration()>duration) {
				m1.put(e.getKey(), e.getValue());
			}
		}
		return m1;
	}
	@Override
	public Map<String, Course> sortByName() {
		Map<String,Course> m1=new TreeMap<String, Course>();
		Set<String> set = map.keySet();
		for(String s:set) {
			m1.put(s, map.get(s));
		}
				return m1;
	}
	@Override
	public List< Course> sortByDur() {
		List<Course> lst = new ArrayList<Course>();
		Set<String> cset=map.keySet();
		for(String key:cset) {
			lst.add(map.get(key));
			lst.sort(null);
			
		}return lst;
	}
	

}
