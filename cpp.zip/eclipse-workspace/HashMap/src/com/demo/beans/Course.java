package com.demo.beans;

public class Course implements Comparable<Course> {
	private String courseName ;
	private int intake;
	private int Fees ;
	private int duration ;
	
	public Course() {
		super();
	}
	
	
	public Course(String courseName, int intake, int fees, int duration) {
		super();
		this.courseName = courseName;
		this.intake = intake;
		Fees = fees;
		this.duration = duration;
	}


	public String getCourseName() {
		return courseName;
	}


	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}


	public int getIntake() {
		return intake;
	}


	public void setIntake(int intake) {
		this.intake = intake;
	}


	public int getFees() {
		return Fees;
	}


	public void setFees(int fees) {
		Fees = fees;
	}


	public int getDuration() {
		return duration;
	}


	public void setDuration(int duration) {
		this.duration = duration;
	}


	@Override
	public String toString() {
		return "Course [courseName=" + courseName + ", intake=" + intake + ", Fees=" + Fees + ", duration=" + duration
				+ "]";
	}


	@Override
	public int compareTo(Course o) {
		
		return this.duration-o.duration;
	}

	
	
	
	
	
}
