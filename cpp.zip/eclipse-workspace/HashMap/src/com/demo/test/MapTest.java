package com.demo.test;


import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.demo.beans.Course;
import com.demo.service.MapService;
import com.demo.service.MapServiceImpl;

public class MapTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		MapService ss = new MapServiceImpl();
		int choice = 0;
		do {
			System.out.println("1. add new course\n2. delete course\n3. update course\n4. display all");
			System.out.println("5. display by name\n6. display based on duration\n7. display in sorted order of course name\n8. display in sorted order of duration\n9.exit\nchoice:");
			choice = sc.nextInt();
			switch(choice) {
			case 1->{
				boolean status = ss.addCourse();
				if(status) {
					System.out.println("course added successfully.");
				}else {
					System.out.println("error occured while making new course...");
				}
			}
			
			case 2->{
				System.out.println("enter the name of course to be deleted");
				String nm = sc.next();
				boolean status = ss.deleteCourse(nm);
				if(status) {
					System.out.println("Course deleted succesfully");
				}
				else {
					System.out.println("course not found");
				}
			}
			case 3->{
				System.out.println("enter the name of course to be updated");
				String nm = sc.next();
				System.out.println("enter new Course intake");
				int intake = sc.nextInt();
				System.out.println("enter new fees");
				int fees = sc.nextInt();
				System.out.println("enter new duration");
				int dur = sc.nextInt();
				boolean status = ss.updateCourse(nm,intake , fees, dur);
				if(status) {
					System.out.println("course Updated successfully.");
				}else {
					System.out.println("error occured while updating course...");
				}

			}
			case 4->{
				Map<String, Course> m = ss.getAll();
				for(Map.Entry<String, Course> e : m.entrySet()) {
					System.out.println(e.getKey() + " "+e.getValue());
				}
			}
			case 5->{
				System.out.println("Enter course name ");
				String cname = sc.next();
				Map<String, Course> m = ss.getByName(cname);
				for(Map.Entry<String, Course> e : m.entrySet()) {
					System.out.println(e.getKey() + " "+e.getValue());
				}
			}
			
			case 6 ->{
				System.out.println("Enter duration");
				int duration = sc.nextInt();
				Map<String,Course> m = ss.getByDur(duration);
				if(m.isEmpty()) {
					System.out.println("not found");
				}else {
					for(Map.Entry<String, Course> e : m.entrySet()) {
						
						System.out.println(e.getKey() + " "+e.getValue());
					}
				}
				
			}
			
			case 7->{
				
				Map<String, Course> m = ss.sortByName();
				for(Map.Entry<String, Course> e : m.entrySet()) {
					System.out.println(e.getKey() + " "+e.getValue());
				}
				
			}
			case 8->{
				List< Course> m = ss.sortByDur();
				m.stream().forEach(c->System.out.println(c));
			}
			}
		}while(choice!= 9);
	}

}
