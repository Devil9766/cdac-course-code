
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Test {
	public static void main(String[] args) {
		List<Integer> list = List.of(1,2,3,4,56,6,78,98);
		List<Integer> lst1 = list.stream().filter(num->num%4==0).collect(Collectors.toList());
		Optional<Integer> op = list.stream().filter(num->num%4==0).findAny();
		Optional<Integer> op1 = list.stream().reduce((acc,num)->acc>num?acc:num);
		System.out.println(op1.get());
		Predicate<Integer> arr = num->{
			System.out.println(num);
			return num%5==0;
			};
		System.out.println(lst1);
		if(op.isPresent()) {
			System.out.println(op.get());
		}else {
			System.out.println("not found");
		}
		
		System.out.println(lst1.stream().noneMatch(num->num>5));
	}
}
