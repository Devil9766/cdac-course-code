package com.demo.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.demo.service.DaoService;
import com.test.beans.GraduateStudent;
import com.test.beans.MasterGraduate;
import com.test.beans.Person;
import com.test.beans.Student;

public class DaoInterfaceImpl implements DaoInterface {
	static List<Student> per ;
	static {
		per = new ArrayList<>();
		per.add(new GraduateStudent(12 , "ashish", "ashishi@gmail.com", "7884454545" , new int[] {88,87}, 85));
		per.add(new MasterGraduate(15, "Manjiri", "iwiadiahdo@gmail.com","46545646546",  new int[] {88,87},89, "Engineering"));
		per.add(new GraduateStudent(13, "Mugdha", "djadbjkabd@dkjakdl.com","65456466", new int[] {78,75},77));
    	per.add(new MasterGraduate(14, "Sahil", "dsjdbakjdba@jdja.com","46465465", new int[] {88,87},89,"BCOM"));
	}
	
	@Override
	public boolean addStudent(Student s) {
		// TODO Auto-generated method stub
		
		return per.add(s);
		
	}
	@Override
	public List<Student> getAllStu() {
		System.out.println("in daoINterIMpl");

		return per;
	}
	@Override
	public boolean removeStu(int id) {
		System.out.println("dao");
		return  per.remove(new Person(id));
		
	}
	@Override
	public Student getById(int id) {
		for(int i=0;i<per.size();i++) {
				if(per.get(i).getId()==id) {
					return per.get(i);
				}
		}
		return null;
	}
	@Override
	public boolean modifyMarks(int id, int newM) {
		Student s = getById(id);
		if(s!= null) {
			if(s instanceof GraduateStudent) {
				((GraduateStudent) s).setSpSub(newM);
				
			}else if(s instanceof MasterGraduate) {
				((MasterGraduate) s).setThesisMarks(newM);;
			}return true;
		}
		return false;
	}
	@Override
	public List<Student> getByMarks(int marks) {
		List<Student> s = new ArrayList<>();  
		for(int i = 0; i< per.size(); i++) {
			
			if(s instanceof GraduateStudent) {
				if(((GraduateStudent) s).getSpSub()==marks) {
					s.add(per.get(i));
				}
				
			}else if(s instanceof MasterGraduate) {
				if(((MasterGraduate) s).getThesisMarks()==marks) {
					s.add(per.get(i));
				}
				
			}
			
		}
		return s;
	}


}
