package com.demo.dao;

import java.util.List;

import com.test.beans.Student;

public interface DaoInterface {

	boolean addStudent(Student s);

	List<Student> getAllStu();

	boolean removeStu(int id);

	Student getById(int id);

	boolean modifyMarks(int id, int newM);

	List<Student> getByMarks(int marks);

}
