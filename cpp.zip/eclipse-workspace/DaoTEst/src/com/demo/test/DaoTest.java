package com.demo.test;

import java.util.List;
import java.util.Scanner;

import com.demo.service.DaoService;
import com.demo.service.DaoServiceImpl;
import com.test.beans.Student;

public class DaoTest {

	public static void main(String[] args) {
		DaoService obj = new DaoServiceImpl();
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		do {
			System.out.println("1. add new student\n2. delete student by id\n 3. modify marks\n4. search by id");
			System.out.println("5. search by marks > given marks\n6. sort by id\n 7. sort by name\n8. sort by marks");
			System.out.println("9.display all\n10. search by name and display in sorted order\n 11. exit\nchoice:");
			choice = sc.nextInt();
			switch(choice) {
			case 1->{
		         System.out.println("1. MasterStudent\n 2. GraduateStudent\n3. faculty\n choice: ");
		         int ch=sc.nextInt();
		         
		         
				boolean ok=obj.addStudent(ch);
				if(ok) {
					System.out.println("Added successfully");
				}else {
					System.out.println("Not added");
				}
			}
			case 2->{
				System.out.println("Enter id to remove");
				int id = sc.nextInt();
				boolean status = obj.removeStudent(id);
				if(status) {
					System.out.println("removed successfully");
				}else {
					System.out.println("not found");
				}
			}
			case 3->{
				System.out.println("enter id to change");
				int id = sc.nextInt();
				System.out.println("enter new change");
				int newM = sc.nextInt();
				boolean ok = obj.modifyMarks(id , newM);
				if(ok) {
					System.out.println("modified successfully");
				}else {
					System.out.println("not found");
				}
					
				}
			case 4 ->{
				System.out.println("Enter id");
				int id = sc.nextInt();
				Student s= obj.getById(id);
				if(s!=null) {
					System.out.println(s);
				}else {
					System.out.println("not found");
				}
			}
				case 5 ->{
					System.out.println("enter marks");
					int marks = sc.nextInt();
					List<Student> stu = obj.findByMarks(marks);
					if(stu != null) {
						stu.stream().forEach( System.out::println);
					}else {
						System.out.println("not found");
					}
				}
				
			
			case 9->{
				List<Student> s =obj.showAll();
				s.stream().forEach(ob-> System.out.println(ob));
				
			}
			}
		}while(choice != 10);
	}

}
