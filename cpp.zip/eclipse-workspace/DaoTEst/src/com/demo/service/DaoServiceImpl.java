package com.demo.service;

import java.util.List;
import java.util.Scanner;

import com.demo.dao.DaoInterface;
import com.demo.dao.DaoInterfaceImpl;
import com.test.beans.GraduateStudent;
import com.test.beans.MasterGraduate;
import com.test.beans.Student;

public class DaoServiceImpl implements DaoService {
	private DaoInterface dc ;
	
	Scanner sc = new Scanner(System.in);
	public DaoServiceImpl() {
		super();
		dc = new DaoInterfaceImpl();
	}


	@Override
	public boolean addStudent(int ch) {
		
		System.out.println("enter student id");
		int id=sc.nextInt();
		System.out.println("enter name");
		String nm=sc.next();
		System.out.println("enter email");
		String email=sc.next();
		System.out.println("enter mob");
		String mob=sc.next();
		int[] marks=new int[2];

		if(ch==1 || ch==2) {
			System.out.println("enetr marks 1");
			marks[0]=sc.nextInt();
			System.out.println("enetr marks 2");
			marks[1]=sc.nextInt();
		}
		Student s=null;
		if(ch==1) {
			System.out.println("enter thesis marks");
			int thesis = sc.nextInt();
			System.out.println("enter degree");
			String deg = sc.next();
			s=new MasterGraduate(id,nm,email,mob,marks,thesis,deg);
		}else if(ch==2) {
			System.out.println("enter special sub marks");
			int spec = sc.nextInt();
			s=new GraduateStudent(id,nm,email,mob,marks,spec);
		}
		return dc.addStudent(s);
	}


	@Override
	public List<Student> showAll() {
		System.out.println("in daoserIMpl");
		return dc.getAllStu();
	}


	@Override
	public boolean removeStudent(int id) {
		System.out.println("serv");
		return dc.removeStu(id);
	}


	@Override
	public Student getById(int id) {
		return dc.getById(id);
	}


	@Override
	public boolean modifyMarks(int id, int newM) {
		return dc.modifyMarks(id , newM);
	}


	@Override
	public List<Student> findByMarks(int marks) {
		return dc.getByMarks(marks);
	}

}
