package com.demo.service;

import java.util.List;

import com.test.beans.Student;

public interface DaoService {

boolean addStudent(int ch);

List<Student> showAll();

boolean removeStudent(int id);

Student getById(int id);

boolean modifyMarks(int id, int newM);

List<Student> findByMarks(int marks);

}
