package com.test.beans;

public class GraduateStudent extends Student {
	private int spSub;

	public GraduateStudent() {
		super();
	}

	public GraduateStudent(int id, String name, String email, String mobNo, int[] marks, int spSub) {
		super(id, name, email, mobNo, marks);
		this.spSub = spSub;
	}

	public int getSpSub() {
		return spSub;
	}

	public void setSpSub(int spSub) {
		this.spSub = spSub;
	}

	@Override
	public String toString() {
		return super.toString() + "GraduateStudent [spSub=" + spSub + "]";
	}
	
}
