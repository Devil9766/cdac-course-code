package com.test.beans;

public class MasterGraduate extends Student{
	private int thesisMarks;
	private String degree;
	public MasterGraduate() {
		super();
	}
	public MasterGraduate(int id, String name, String email, String mobNo, int[] marks, int thesisMarks,
			String degree) {
		super(id, name, email, mobNo, marks);
		this.thesisMarks = thesisMarks;
		this.degree = degree;
	}
	public int getThesisMarks() {
		return thesisMarks;
	}
	public void setThesisMarks(int thesisMarks) {
		this.thesisMarks = thesisMarks;
	}
	@Override
	public String toString() {
		return super.toString()+"MasterGraduate [thesisMarks=" + thesisMarks + ", degree=" + degree + "]";
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	
}
