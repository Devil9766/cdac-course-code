package com.test.beans;

import java.util.Arrays;

public class Student extends Person {
private int[] marks;

public Student() {
	super();
}

public Student(int id, String name, String email, String mobNo, int[] marks) {
	super(id, name, email, mobNo);
	this.marks = marks;
}

public int[] getMarks() {
	return marks;
}

public void setMarks(int[] marks) {
	this.marks = marks;
}

@Override
public String toString() {
	return super.toString() +  "Student [marks=" + Arrays.toString(marks) + "]";
}




}
