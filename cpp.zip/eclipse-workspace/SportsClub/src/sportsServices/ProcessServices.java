package sportsServices;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.sports.beans.Contract;
import com.sports.beans.Employee;
import com.sports.beans.Members;
import com.sports.beans.Salaried;
import com.sports.beans.Vendor;

public class ProcessServices {
	static Employee[] emp = new Employee[10];
	static Members[] mem = new Members[10];
	static int empcount = 0;
	static int memcount = 0;
	
	public static boolean createEmp(int ch) {
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter id :");
		String id = sc.nextLine();
		System.out.println("Enter name : ");
		String name = sc.nextLine();
		System.out.println("Enter mobile no");
		String mobno = sc.nextLine();
		System.out.println("Enter email");
		String email = sc.nextLine();
		System.out.println("Enter designation");
		String desig = sc.nextLine();
		System.out.println("Enter date of joining");
		String doj = sc.next() ;
		LocalDate ldt=LocalDate.parse(doj, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
	
			if(ch ==1) {
				System.out.println("Enter basic salary");
				int bSal = sc.nextInt();
				emp[empcount] = new Salaried(id, name, mobno, email, desig, ldt, bSal);
				empcount++;

				return true;
				
			}else if(ch ==2) {
				System.out.println("no of hrs");
				int noH = sc.nextInt();
				System.out.println("per hr rate");
				int pHR = sc.nextInt();
				emp[empcount] = new Contract(id, name, mobno, email, desig, ldt, noH , pHR);
				empcount++;
				return true;
			}
			else if(ch ==3) {
				System.out.println("no of emp");
				int noE = sc.nextInt();
				System.out.println("amount");
				int amt = sc.nextInt();
				emp[empcount] = new Vendor(id, name, mobno, email, desig, ldt, noE , amt);
				empcount++;
				
			}return false;
	}
	public static void display() {
		for(int i = 0 ; i< empcount ; i++) {
			System.out.println(emp[i]);
		}
		for(int j = 0 ; j < memcount; j++) {
			System.out.println(mem[j]);
		}
	}
	


}
