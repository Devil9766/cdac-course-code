package sportstest;

import java.time.LocalDate;
import java.util.Scanner;

import com.sports.beans.Salaried;

import sportsServices.ProcessServices;

public class TestSports {
	public static void main(String[] args) {
//		Salaried sal = new Salaried("12","Ashish","9822467456","ashish@gmail.com","developer",LocalDate.of(12, 12, 12),22000); 
//	    System.out.println(sal);
		int choice =0;
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("1.Create emp \n 2.Create member \n3.display emp\n 4.Exit");
		 choice = sc.nextInt();
		 
			switch(choice){
			case 1 :
				System.out.println("Enter your choice : \n 1.Salaried \n2.Contract \n3.Vendor\n");
				int ch=sc.nextInt();
				boolean ok =ProcessServices.createEmp(ch);
				if(ok) {
					System.out.println("Emp created successfully");
				}else {
					System.out.println("emp not created");
				}
				
				break;
			case 3:
				ProcessServices.display();
				break;
			}
		}while(choice !=4);
	}
	
}
