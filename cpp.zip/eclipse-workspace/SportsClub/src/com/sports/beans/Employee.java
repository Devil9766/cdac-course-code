package com.sports.beans;

import java.time.LocalDate;

public class Employee extends Person {
	private String desig ;
	private LocalDate doj;
	
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Employee(String id, String name, String mob, String email, String desig, LocalDate doj) {
		super(id, name, mob, email);
		this.desig = desig;
		this.doj = doj;
	}


	public String getDesig() {
		return desig;
	}


	public void setDesig(String desig) {
		this.desig = desig;
	}


	public LocalDate getDoj() {
		return doj;
	}


	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}


	@Override
	public String toString() {
		return super.toString() + "Employee [desig=" + desig + ", doj=" + doj + "]";
	}
	
	


	
	

}
