package com.sports.beans;

public class Members extends Person {
	private String typeOM;
	private int amountPaid;
	public Members() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Members(String id, String name, String mob, String email , String typeOM, int amountPaid) {
		super(id, name, mob, email);
		this.typeOM = typeOM;
		this.amountPaid = amountPaid;
	}
	public String getTypeOM() {
		return typeOM;
	}
	public void setTypeOM(String typeOM) {
		this.typeOM = typeOM;
	}
	public int getAmountP() {
		return amountPaid;
	}
	public void setAmountP(int amountP) {
		this.amountPaid = amountPaid;
	}
	@Override
	public String toString() {
		return super.toString() +"Members [typeOM=" + typeOM + ", amountP=" + amountPaid + "]";
	}
	
	

	
	
}
