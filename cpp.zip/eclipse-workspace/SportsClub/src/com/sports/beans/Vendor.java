package com.sports.beans;

import java.time.LocalDate;

public class Vendor extends Employee {
	private int nOfEmp;
	private int amount;
	public Vendor() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Vendor(String id, String name, String mob, String email, String desig, LocalDate doj, int nOfEmp, int amount) {
		super(id, name, mob, email, desig, doj);
		this.nOfEmp = nOfEmp;
		this.amount = amount;
	}
	public int getnOfEmp() {
		return nOfEmp;
	}
	public void setnOfEmp(int nOfEmp) {
		this.nOfEmp = nOfEmp;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return super.toString() + "Vendor [nOfEmp=" + nOfEmp + ", amount=" + amount + "]";
	}
	
	
}
