package com.sports.beans;

import java.time.LocalDate;

public class Salaried extends Employee {
	private int bSalary;

	public Salaried() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Salaried(String id, String name, String mob, String email, String desig, LocalDate doj, int bSalary) {
		super(id, name, mob, email, desig, doj);
		this.bSalary = bSalary;// TODO Auto-generated constructor stub
	}

	public int getbSalary() {
		return bSalary;
	}

	public void setbSalary(int bSalary) {
		this.bSalary = bSalary;
	}

	@Override
	public String toString() {
		return super.toString() + "Salaried [bSalary=" + bSalary + "]";
	}

	
}
