package com.sports.beans;

import java.time.LocalDate;

public class Contract extends Employee {
	private int nHr;
	private int pHR ;
	public Contract() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Contract(String id, String name, String mob, String email, String desig, LocalDate doj, int nHr, int pHR) {
		super(id, name, mob, email, desig, doj);
		this.nHr = nHr;
		this.pHR = pHR;
	}
	public int getnHr() {
		return nHr;
	}
	public void setnHr(int nHr) {
		this.nHr = nHr;
	}
	public int getpHR() {
		return pHR;
	}
	public void setpHR(int pHR) {
		this.pHR = pHR;
	}
	@Override
	public String toString() {
		return super.toString() + "Contract [nHr=" + nHr + ", pHR=" + pHR + "]";
	}
	
	
	
	
}
