package test;

import java.util.Scanner;

import beans.AccountInfo;
import services.AccountServicesImpl;
import services.accountServices;

public class AccountTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		accountServices ac = new AccountServicesImpl();
		int choice =0;
		do {
			System.out.println("1. Add new Account\n2. Delete by id\n3. withdrawal\n");
			System.out.println("4. deposit\n5. check balance\n6. display all\n7. exit\n choice :");
			choice=sc.nextInt();
			switch(choice) {
			case 1 : 
				ac.createAcc();
				break;
			case 2 : 
				System.out.println("enter id to dele");
				int id = sc.nextInt();
				System.out.println("enter pin");
				int pin = sc.nextInt();
				int status = ac.deleteAcc(id , pin);
				if(status>0) {
					System.out.println("Account closed");
				}else if(status==-1) {
					System.out.println("not found");
				}else {
					System.out.println("pin is wrong");
				}
				
				break;
			case 3 : 
				System.out.println("enter id ");
				 id = sc.nextInt();
				System.out.println("enter pin");
				 pin = sc.nextInt();
				 System.out.println("enter amt");
				int amt=sc.nextInt();
				boolean ok=ac.withdraw(id,pin,amt);
				if(ok) {
					System.out.println("withdraw successful");
				}else {
					System.out.println("withdraw failed");
				}
				break;
			case 4 : 
				System.out.println("enter id ");
				 id = sc.nextInt();
				System.out.println("enter pin");
				 pin = sc.nextInt();
				 System.out.println("enter amt");
				 amt=sc.nextInt();
				ok=ac.deposite(id, pin, amt);
				if(ok) {
					System.out.println("deposite successful");
				}else {
					System.out.println("deposite failed");
				}
				break;
			case 5 : 
				System.out.println("enter id ");
				 id = sc.nextInt();
				System.out.println("enter pin");
				 pin = sc.nextInt();
				double bal=ac.checkBal(id,pin);
				System.out.println(bal);
				break;
			case 6 : 
				AccountInfo[] arr = new AccountInfo[100];
				arr=ac.displayAll();
				if(arr!=null) {
					for(int i=0;i<arr.length;i++) {
						if(arr[i]!=null) {
							System.out.println(arr[i]);
						}else {
							break;
						}
					}
					
				}
				
				break;
			}
		}while(choice != 7);

	}

}
