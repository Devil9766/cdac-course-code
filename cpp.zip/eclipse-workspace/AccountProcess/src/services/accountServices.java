package services;

import beans.AccountInfo;

public interface accountServices {

	void createAcc();

	int deleteAcc(int id, int pin);

	AccountInfo[] displayAll();

	boolean withdraw(int id, int pin,int amt);

	double checkBal(int id,int pin);


	boolean deposite(int id, int pin, int amt);

}
