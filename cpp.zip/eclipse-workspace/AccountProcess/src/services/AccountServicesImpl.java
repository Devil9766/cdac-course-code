package services;

import java.util.Scanner;

import beans.AccountInfo;

public class AccountServicesImpl implements accountServices {
	
	static AccountInfo[] arr ;
	static int cnt ;
	static {
		cnt = 0;
		arr = new AccountInfo[100];
		arr[0]=new AccountInfo(1,"Rajan",345676,1111);
    	arr[1]=new AccountInfo(2,"Atharva",345688,2222);
    	cnt=2;
	}
	@Override
	public void createAcc() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter id : ");
		int id = sc.nextInt();
		System.out.println("enter name : ");
		String name = sc.next();
		System.out.println("enter balance : ");
		 int bal= sc.nextInt();
		 System.out.println("enter pin : ");
		 int pin = sc.nextInt();
		 arr[cnt]=new AccountInfo(id,name,bal,pin);
			cnt++;
		
	}
	public static int findByID(int id , int pin) {
		for(int i = 0; i< arr.length ; i++) {
			if(arr[i].getId() == id) {
				if(arr[i].getPin() == pin) {
					return i;
				}else {
					return -2;
				}
			}
		}return -1;
	}
	@Override
	public int deleteAcc(int id, int pin) {
		int pos = findByID(id, pin);
		if(pos>= 0) {
		for(int  j = pos ; j< cnt ; j++) {
			arr[j] = arr[j+1];
		}
		}return pos;
		
	}
	@Override
	public AccountInfo[] displayAll() {
		return arr;
	}
	@Override
	public boolean withdraw(int id, int pin,int amt) {
		int pos=findByID(id, pin);
		if(pos>=0) {
			if(arr[pos].getBalance()>=amt) {
				double am = arr[pos].getBalance();
				am = am- amt;
				arr[pos].setBalance(am);
				return true;
			}
		}
			return false;
		
		
		
		}
	@Override
	public double checkBal(int id,int pin) {
		int pos = findByID(id, pin);
		return arr[pos].getBalance();
	}
	
	public boolean deposite(int id, int pin, int amt) {
		int pos=findByID(id, pin);
		if(pos>=0) {
			 {
				double am = arr[pos].getBalance();
				am = am+ amt;
				arr[pos].setBalance(am);
				return true;
			}
		
	
			}return false;
	}

}
