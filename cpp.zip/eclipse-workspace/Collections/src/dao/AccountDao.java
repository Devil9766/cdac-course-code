package dao;

import java.util.List;
import java.util.Set;

import com.demo.exception.PinNotFound;
import com.demo.exception.WrongCred;

import beans.Account;

public interface AccountDao {

	boolean saveaccount(Account ac);

	Set<Account> displayAll();

	Account findById(String id, int pin);

	double checkBal(String id, int pin) throws WrongCred;

	boolean deleteAcc(String id, int pin);

	boolean changePin(String id, int pin) throws PinNotFound;

	Set<Account> sortById();

	List<Account> sortByName();

	

}
