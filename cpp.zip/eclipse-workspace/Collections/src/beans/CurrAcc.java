package beans;

public class CurrAcc extends Account{
	private int min_transaction;
	private static float int_rate;
	private static float min_balance;
	static {
		int_rate=0.02f;
		min_balance=0f;
	}
	public CurrAcc() {
		super("c");
	}
	public CurrAcc( String name, int pin, String q, String ans, double amt, int min_transaction) {
		super("c", name, pin, q, ans, amt);
		this.min_transaction = min_transaction;
	}
	public int getMin_transaction() {
		return min_transaction;
	}
	public void setMin_transaction(int min_transaction) {
		this.min_transaction = min_transaction;
	}
	public static float getInt_rate() {
		return int_rate;
	}
	public static void setInt_rate(float int_rate) {
		CurrAcc.int_rate = int_rate;
	}
	public static float getMin_balance() {
		return min_balance;
	}
	public static void setMin_balance(float min_balance) {
		CurrAcc.min_balance = min_balance;
	}
	@Override
	public String toString() {
		return super.toString()+"CurrAcc [min_transaction=" + min_transaction + "]";
	}
	@Override
	public int withdraw(double amt) {
		if(balance-amt >= min_balance) {
			balance -= amt;
			return 1;
		}
		return 2;
		
		
		
	}
	
	
	
}