package beans;

public class Saving extends Account{
	private int chequeBkNum;
	static float int_rate;
	static float min_balance;
	static {
		int_rate=0.04f;
		min_balance=5000f;
	}
	public Saving() {
		super("s");
	}
	public Saving( String name, int pin, String q, String ans, double amt, int chequeBkNum) {
		super("s", name, pin, q, ans, amt);
		this.chequeBkNum = chequeBkNum;
	}
	public int getChequeBkNum() {
		return chequeBkNum;
	}
	public void setChequeBkNum(int chequeBkNum) {
		this.chequeBkNum = chequeBkNum;
	}
	public static float getInt_rate() {
		return int_rate;
	}
	public static void setInt_rate(float int_rate) {
		Saving.int_rate = int_rate;
	}
	public static float getMin_balance() {
		return min_balance;
	}
	public static void setMin_balance(float min_balance) {
		Saving.min_balance = min_balance;
	}
	@Override
	public String toString() {
		return super.toString()+"Saving [chequeBkNum=" + chequeBkNum + "]";
	}
	
	public int withdraw(double amt) {
		if(balance-amt >= min_balance) {
			balance -= amt;
			return 1;
		}
		return 2;
		
		
		
	}
	
	
	
}
