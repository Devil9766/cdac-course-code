package beans;

public abstract class Account implements Comparable<Account> {
	static int cnt;
	static {cnt=0;}
	private String id;
	private String name;
	private int pin;
	private String Q;
	private String ans;
	protected double balance;
	@Override
	public String toString() {
		return "Account [id=" + id + ", name=" + name + ", pin=" + pin + ", Q=" + Q + ", ans=" + ans + ", balance="
				+ balance + "]";
	}
	
	public static int getCnt() {
		return cnt;
	}
	public static void setCnt(int cnt) {
		Account.cnt = cnt;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public String getQ() {
		return Q;
	}
	public void setQ(String q) {
		Q = q;
	}
	public String getAns() {
		return ans;
	}
	public void setAns(String ans) {
		this.ans = ans;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public Account(String type, String name, int pin, String q, String ans, double amt) {
		super();
		this.id=generateId(type,name);
		this.name = name;
		this.pin = pin;
		this.Q = q;
		this.ans = ans;
		this.balance = amt;
	}
	
	
	

	public Account(String type) {
		super();
		this.id = generateId(type, null);
	}

	private String generateId(String type,String name) {
		String id=null;
		if(name!=null) {
			id=type+name.substring(0,2)+cnt;
		}else {
			id=type+"xx"+cnt;
		}
		cnt++;
		return id;
	}
	public int hashCode() {
		System.out.println("In account hashcode"+name+"---"+pin);
		return name.hashCode()+pin;
	}
	
	public boolean equals(Account obj) {
		Account ac = (Account)obj;
		return this.name.equals(ac.name) && this.pin==ac.pin;
	}

	abstract public int withdraw(double amt) ;

	public boolean depositAmount(double amt) {
		this.balance += amt;
		return true;
	}
	
	public int compareTo(Account ob) {
		System.out.println("in compareTo account : "+this.id+"----"+ob.id);
		return this.id.compareTo(ob.id);
	}
	
		
}
