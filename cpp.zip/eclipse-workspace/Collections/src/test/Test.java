package test;

import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.demo.exception.PinNotFound;
import com.demo.exception.WrongCred;

import beans.Account;
import services.AccountService;
import services.AccountServiceImpl;
import services.LoginService;
import services.LoginServiceImpl;

public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		AccountService ss = new AccountServiceImpl();
		LoginService lo = new LoginServiceImpl();
		System.out.println("enter usernaem: ");
		String user = sc.next();
		System.out.println("enter password: ");
		String pass = sc.next();
		String role = lo.authenticate(user , pass);
		int choice = 0;
		if(role.equals("user")) {
			do {
				System.out.println("1.Open new account\n2. withdraw amt\n3. deposit amount\n4. transfer funds\n");
				System.out.println("5.change pin\n6. check balance\n7. close account\n8. display all\n9 exit\nchoice");
				choice = sc.nextInt();
				switch(choice) {
				case 1 ->{
					 System.out.println("1. Saving\n 2. Current\n choice: ");
					   int ch=sc.nextInt();
					boolean status = ss.createAccount(ch);
					if(status) {
						   System.out.println("Account opening done");
					   }else{
						   System.out.println("error occured");
					   }
				}
				case 2->{
					
					System.out.println("Enter id");
					String id = sc.next();
					System.out.println("enter pin");
					int pin = sc.nextInt();
					System.out.println("enter amt");
					double amt = sc.nextInt();
					
					int status;
					try {
						status = ss.withdraw(id,pin,amt);
						if(status==1) {
							System.out.println("withdrawn successfully");
						}
					} catch (WrongCred e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
					
				}
				
				case 3 ->{
					System.out.println("Enter id");
					String id = sc.next();
					System.out.println("enter pin");
					int pin = sc.nextInt();
					System.out.println("enter amt");
					double amt = sc.nextInt();
					
					
					try {
						boolean status=ss.deposit(id,pin,amt);
						if(status) {
							System.out.println("deposited successfully");
						}
					} catch (WrongCred e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
					
				}
				
				case 5->{
					try { System.out.println("enter id");
					 String id =sc.next();
					System.out.println("enter pin");
					 int pin =sc.nextInt();
					
					 
					 boolean status=ss.changePin(id,pin);
					}catch(PinNotFound e) {
						System.out.println(e.getMessage());
					}
				}
				case 6->{
					try {
					System.out.println("enter id");
					 String id =sc.next();
					System.out.println("enter pin");
					 int pin =sc.nextInt();
					 
					 double bal = ss.checkBal(id,pin);
					 System.out.println("Your balance is : " + bal);
					}catch(WrongCred e) {
						System.out.println(e.getMessage());
					}
				}
				case 7->{
					System.out.println("enter id");
					 String id =sc.next();
					System.out.println("enter pin");
					 int pin =sc.nextInt();
					 boolean status = ss.deleteAccount(id ,pin);
					 if(status) {
						 System.out.println("Account closed successfully.");
					 }else {
						 System.out.println("account not found.");
					 }
					 
				}
				case 8->{
					Set<Account> acc = ss.displayAll(); 
					acc.stream().forEach(System.out::println);
				}
				case 9->{
					System.out.println("Thanks for visiting!!!");
					sc.close();
				}
				default->{
					System.out.println("wrong choice");
				}
				}
			}while(choice != 9);
		}else if(role.equals("admin")) {
			do {
				System.out.println("1. Display All account\n2. display in sorted order by id\n3. display in sorted order by name\n");
				System.out.println("4. exit\n choice: ");
				choice = sc.nextInt();
				switch(choice) {
				case 1->{
					Set<Account> admin = ss.displayAll();
					admin.stream().forEach(System.out::println);
				}
				
				case 2->{
					Set<Account> aset=ss.sortById();
					aset.stream().forEach(System.out::println);
				}
				case 3->{
					List<Account> aset = ss.sortByName();
					aset.stream().forEach(System.out::println);
				}
				}
			}while(choice!= 4);
		}
	}
}
