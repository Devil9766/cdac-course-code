package com.demo.exception;

public class PinNotFound extends Exception{



	public PinNotFound(String msg) {
		super(msg);
	}
	


}
