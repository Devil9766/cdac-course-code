package com.demo.exception;

public class WrongCred extends Exception{

	public WrongCred(String msg) {
		super(msg);
	}
	
}
