package services;

public class LoginServiceImpl implements LoginService {

	@Override
	public String authenticate(String user, String pass) {
		if(user.equals("user1") && pass.equals("user1")) {
			return "user";
		}else if(user.equals("admin1") && pass.equals("admin1")){
			return "admin";
		}else {
			return null;
		}
	}
	
}
