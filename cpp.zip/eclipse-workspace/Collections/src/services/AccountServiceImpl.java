package services;

import java.util.Currency;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.demo.exception.PinNotFound;
import com.demo.exception.WrongCred;

import beans.Account;
import beans.CurrAcc;
import beans.Saving;
import dao.AccountDao;
import dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService {
	private AccountDao dao;
	
	public AccountServiceImpl() {
		dao = new AccountDaoImpl();
		
	}

	@Override
	public boolean createAccount(int ch) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter name");
		String nm = sc.next();
		System.out.println("Enter 4 digit pin");
		int pin=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter secrete question");
		String que=sc.nextLine();
		System.out.println("Enter answer");
		String ans=sc.next();
		System.out.println("Enter amount to be deposited");
		double amt=sc.nextDouble();
		if(ch == 1) {
			System.out.println("Enter chequebook number");
			int cnum=sc.nextInt();
			Account ac=new Saving(nm , pin,que, ans , amt, cnum);
			return dao.saveaccount(ac);
		}else if(ch==2) {
			System.out.println("Enter number of transactions");
			int tnum=sc.nextInt();
			Account ac=new CurrAcc(nm,pin,que,ans,amt,tnum);
			return dao.saveaccount(ac);
		}
		return false;
		
		
	}

	@Override
	public Set<Account> displayAll() {
		return dao.displayAll();
	}
	
	public  Account findById(String id, int pin) {
		return dao.findById(id,pin);
	}
	
	@Override
	public int withdraw(String id, int pin,double amt) throws WrongCred {
		Account ac= dao.findById(id,pin);
		if(ac!=null) {
			 return  ac.withdraw(amt);	
		}
		throw new WrongCred("Entered wrong credential");
	}

	@Override
	public boolean deposit(String id, int pin, double amt) throws WrongCred {
		Account ac = dao.findById(id, pin);
		if(ac!=null) {
			return ac.depositAmount(amt);
		}
		throw new WrongCred("Entered wrong credential");

	}

	@Override
	public double checkBal(String id, int pin) throws WrongCred {
		
		return dao.checkBal(id,pin);
	}

	@Override
	public boolean deleteAccount(String id, int pin) {
		return dao.deleteAcc(id , pin);
	}

	@Override
	public boolean changePin(String id, int pin) throws PinNotFound {
	
		return dao.changePin(id,pin);
	}

	@Override
	public Set<Account> sortById() {
		return dao.sortById();
	}

	@Override
	public List<Account> sortByName() {
		return dao.sortByName();
	}
	
	

}
