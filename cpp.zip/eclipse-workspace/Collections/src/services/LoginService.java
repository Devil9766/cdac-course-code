package services;

public interface LoginService {

	String authenticate(String user, String pass);

}
