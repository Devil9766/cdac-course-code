package services;

import java.util.List;
import java.util.Set;

import com.demo.exception.PinNotFound;
import com.demo.exception.WrongCred;

import beans.Account;

public interface AccountService {

	boolean createAccount(int ch);

	Set<Account> displayAll();

	int withdraw(String id, int pin,double amt) throws WrongCred;

	boolean deposit(String id, int pin, double amt) throws WrongCred;

	double checkBal(String id, int pin) throws WrongCred;

	boolean deleteAccount(String id, int pin);

	boolean changePin(String id, int pin) throws PinNotFound;

	Set<Account> sortById();

	List<Account> sortByName();

	

	

}
