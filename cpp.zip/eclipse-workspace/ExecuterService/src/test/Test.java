package test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import beans.MyTask;

public class Test {
	public static void main(String[] args) {
		ExecutorService es = Executors.newFixedThreadPool(4);
		List<Future<Integer>> list = new ArrayList<>();
		int sum=0;
		for(int i=0;i<=91;i=i+10) {
			Future<Integer> fs = es.submit(new MyTask(i, i+9));
			list.add(fs);
			
		}
		 for(Future<Integer> f:list) {
			 try {
				 sum += f.get();
				 }
			 catch(InterruptedException e) { e.printStackTrace();
		  }catch(ExecutionException e) { e.printStackTrace(); } }
		 
		System.out.println("addition"+sum);
		es.shutdown();
	}
}
