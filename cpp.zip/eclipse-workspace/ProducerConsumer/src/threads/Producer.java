package threads;

import beans.Storage;

public class Producer extends Thread{
	private Storage s;

	public Producer(Storage s) {
		super();
		this.s = s;
	}
	
	public void run() {
		for(int i=0;i<=10;i++) {
			s.put(i);
		}
		s.setValueSet(true);
		
	}
	
}
