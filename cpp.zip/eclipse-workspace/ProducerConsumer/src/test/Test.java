package test;
import beans.Storage;
import threads.Consumer;
import threads.Producer;

public class Test {

	public static void main(String[] args) {
		Storage s=new Storage();
		Producer p=new Producer(s);
		Consumer c=new Consumer(s);
		p.start();
		c.start();

	}
}
