package beans;

public class Storage {
	private int n;
	private boolean valueSet;
	public Storage() {
		super();
		valueSet=false;
		
	}
	
	synchronized public void put(int x) {
		if(valueSet) {
		try {
			wait();
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
	}
		System.out.println("in put : "+x);
		n=x;
		valueSet=true;
		notify();
	
}
	
	public int getN() {
		return n;
	}

	public void setN(int n) {
		this.n = n;
	}

	public boolean isValueSet() {
		return valueSet;
	}

	public void setValueSet(boolean valueSet) {
		this.valueSet = valueSet;
	}

	synchronized public void get() {
		if(!valueSet) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println("in get "+n); //consumer functionality
		valueSet=false;
		notify();
	}
	}
