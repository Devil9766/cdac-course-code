package services;

public interface CompareInt<T> {
	T findMax(T x,T y);
	CompareInt<Integer> min =(c,d)->{
	return c<d?c:d;
	};
}
