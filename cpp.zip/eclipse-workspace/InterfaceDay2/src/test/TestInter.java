package test;

import services.CompareInt;

public class TestInter implements CompareInt<T>{

	@Override
	public T findMax(T x, T y) {
	return x>y?x:y;
		

	
	}
	
}
