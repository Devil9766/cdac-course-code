package test;

import services.CompareInt;
import test.TestInter;
public class Test {
	public static void main(String[] args) {
		CompareInt<Float> c = (a,b)->{
			return a>b?a:b;
		};
		CompareInt<Float> min=new CompareInt();
		System.out.println(c.findMax(4.4f,3.3f));
		System.out.println(findMin(4,3));
	}

	private static char[] findMin(int i, int j) {
		// TODO Auto-generated method stub
		return null;
	}
}
