package vector;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;

public class VectorPrac {
	public static void main(String[] args) {
		Vector vec = new Vector(20,5);
		List<Integer> l = new ArrayList<Integer>();
		vec.add("Abc");
		vec.add(1);
		vec.remove(1);
		
//		System.out.println(vec);
//		System.out.println(vec.capacity());
//		System.out.println(vec.size());
		l.add(1);
//		System.out.println(l.get(0));
		
		String s = "sg,te,st";
		System.out.println(s.indexOf("t"));
		System.out.println(s.toUpperCase());
		System.out.println(s.contains("sg"));
		String[] s1=s.split(",");
		
		Arrays.stream(s1).forEach(System.out::println);
		String st = String.join(":", s1);
		System.out.println(st.hashCode());
		System.out.println(s.equals(st));
		StringBuilder s2 = new StringBuilder("hello ");
		s2.append("world");
		System.out.println(s2);
		l.size();
		System.out.println(l.hashCode());
	}

}
