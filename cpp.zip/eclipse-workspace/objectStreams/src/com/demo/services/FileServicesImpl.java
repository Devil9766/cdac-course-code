package com.demo.services;

import java.util.List;
import java.util.Scanner;

import com.demo.beans.Employee;
import com.demo.dao.FileDao;
import com.demo.dao.FileDaoImpl;

public class FileServicesImpl implements FIleServices{
	Scanner sc=new Scanner(System.in);
		private FileDao dao;

		public FileServicesImpl() {
			super();
			dao = new FileDaoImpl();
		}

		@Override
		public void readFile(String string) {
			dao.readFile(string);
			
		}

		@Override
		public void writeFile(String string) {
			dao.writeFile(string);
			
		}

		@Override
		public void addEmp() {
			
			System.out.println("enter id");
			int id=sc.nextInt();
			System.out.println("enter name");
			String nm=sc.next();
			System.out.println("enter email");
			String email=sc.next();
			System.out.println("enter mob");
			String mob=sc.next();
			Employee e=new Employee(id,nm,email,mob);
			
			dao.addEmp(e);
			
		}

		@Override
		public List<Employee> getAll() {
			return dao.getAll();
		}

		@Override
		public boolean deleteEmp(int id) {
			
			return dao.removeEmp(id);
		}

		@Override
		public boolean updateEmp(int id) {
			System.out.println("enter mob");
			String mob=sc.next();
			System.out.println("enter email");
			String email=sc.next();
			return dao.updateEmp(id,mob,email);
			
			
		}
		
}
