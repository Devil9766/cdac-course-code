package com.demo.services;

import java.util.List;

import com.demo.beans.Employee;

public interface FIleServices {

	void readFile(String string);

	void writeFile(String string);

	void addEmp();

	List<Employee> getAll();

	boolean deleteEmp(int id);

	boolean updateEmp(int id);

}
