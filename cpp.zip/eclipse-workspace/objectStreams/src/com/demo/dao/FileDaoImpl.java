package com.demo.dao;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.demo.beans.Employee;

public class FileDaoImpl implements FileDao{
	static List<Employee> lst ;
	static {
		lst = new ArrayList<Employee>();
//		lst.add(new Employee(1,"Ashish","ashish@gmail.com","35411641661"));
	}
	@Override
	public void readFile(String string) {
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(string))) {
			
			while(true) {
				Employee e = (Employee) ois.readObject();
				lst.add(e);
			}
		}catch(EOFException e){
			System.out.println("lines readed--------------->" + lst.size());
		}catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Io exception");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			System.out.println("class not found");
		}
	}
	@Override
	public void writeFile(String string) {
		try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(string))){
			for(Employee e:lst) {
				oos.writeObject(e);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("file not found");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Io exception");
		}
	}
	
	@Override
	public void addEmp(Employee e) {
		lst.add(e);
		
	}
	@Override
	public List<Employee> getAll() {
		return lst;
	}
	@Override
	public boolean removeEmp(int id) {
		
		for(Employee p: lst) {
			if(p.getId() == id) {
				lst.remove(p);
				return true;
			}
		}return false; 
	}
	@Override
	public boolean updateEmp(int id, String mob, String email) {
		for(Employee p: lst) {
			if(p.getId() == id) {
				p.setPhoneNo(mob);
				p.setEmail(email);
				return true;
			}
		}
		return false;
	}

}
