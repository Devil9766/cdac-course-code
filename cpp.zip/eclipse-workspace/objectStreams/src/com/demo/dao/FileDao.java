package com.demo.dao;

import java.util.List;

import com.demo.beans.Employee;

public interface FileDao {

	void readFile(String string);

	void writeFile(String string);

	void addEmp(Employee e);

	List<Employee> getAll();

	boolean removeEmp(int id);

	boolean updateEmp(int id, String mob, String email);

}
