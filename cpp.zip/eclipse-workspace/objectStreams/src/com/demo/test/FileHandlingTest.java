package com.demo.test;

import java.util.List;
import java.util.Scanner;

import com.demo.beans.Employee;
import com.demo.services.FIleServices;
import com.demo.services.FileServicesImpl;

public class FileHandlingTest {
 public static void main(String [] args) {
	 Scanner sc = new Scanner(System.in);
	 
	 FIleServices ser = new FileServicesImpl();
	 int choice = 0;
	 ser.readFile("empData.dat");
	 do {
			System.out.println("1. Add new Employee\n2. delete Employee\n3. update employee\n");
			System.out.println("4. display all\n5.exit\nchoice:");
			choice =sc.nextInt();
		 switch(choice) {
		 case 1->{
			 ser.addEmp();
		 }
		 
		 case 2 ->{
			 System.out.print("enter id to delete : ");
			 int id = sc.nextInt();
			 boolean status = ser.deleteEmp(id);
			 if(status) {
				 System.out.println("employee delete successfully.");
			 }
		 }
		 
		 case 3 ->{
			 System.out.println("enter id to update.");
			 int id = sc.nextInt();
			 boolean status = ser.updateEmp(id);
			 if(status) {
				 System.out.println("employee updated successfully.");
			 }
			 
		 }
		 case 4->{
			List<Employee> emp =  ser.getAll();
			emp.forEach(ob-> System.out.println(ob));
		 }
		 case 5->{
			 ser.writeFile("empData.dat");
			 System.out.println("thank you for visiting....");
				sc.close();
		 }
		 }
	 }while(choice!= 5);
	 
 }
}
