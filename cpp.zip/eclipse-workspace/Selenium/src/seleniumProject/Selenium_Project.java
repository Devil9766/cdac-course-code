package seleniumProject;

public class Selenium_Project {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Launching Chrome Brower
		WebDriverManager.ChromeManager().setup();
		WebDriver driver = new ChromeDriver;
		
		// Launching URL
		driver.get(https://demo.applitools.com/);
			
		//maximize window
		driver.manage().maximize();
			
		//Finding UserID using xpath and entering email ID
		driver.findElement(ById.xpath("//*[@id=\"username\"]"))
		.sendKeys("atharvagurav2010@gmail.com");
		
		// Finding WebElement Password and Entering Password
		driver.findElement(ById.xpath("//*[@id=\"password\"]"))
		.sendKeys("123456");
		//Quitting Browser
		driver.quit();
		
		
		
		

	}

}
