/**
 * 
 */
/**
 * 
 */
module LAB1.java {
}