package enum1;

public enum Coffee {
	small(100,150),medium(200,250),large(300,350);
	private int size;
	private float price;
	private Coffee(int size, float price) {
		this.size = size;
		this.price = price;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
}
