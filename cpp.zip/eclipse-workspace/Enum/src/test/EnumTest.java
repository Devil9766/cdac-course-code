package test;

import java.util.Scanner;

import enum1.Coffee;

public class EnumTest {
	public static void main(String[] args) {
		Coffee c =  Coffee.medium;
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		
			switch(c) {
			
			case small->{
				
				System.out.println("small");
			}
			case medium->{
				
				System.out.println("medium");
			}
			case large->{
				
				System.out.println("large");
			}
			
			}
		
		
	}
}
