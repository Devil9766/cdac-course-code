package exception;

import java.util.Scanner;

public class ExceptionTest {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a=0,b=0;
		try {
			try {
				System.out.println("enter a");
				 a=sc.nextInt();
				System.out.println("enter b");
				 b=sc.nextInt();
				throw new IpMismatch("enter number not a string,");
			} catch (IpMismatch e) {
				System.out.println(e.getMessage());
			}
			
			int ans = a/b;
			
			
		}catch (ArithmeticException e) {
			System.out.println( "number cannote be divided by zero.");
			System.out.println(e.getMessage());
		}
	}
}
