package exception;

public class IpMismatch extends Exception{
	public IpMismatch(String msg) {
		super(msg);
	}
	
}
