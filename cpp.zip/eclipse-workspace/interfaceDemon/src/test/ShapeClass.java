package test;

import interface1.Circle;
import interface1.Rectangle;
import interface1.Triangle;

public class ShapeClass implements Circle, Triangle, Rectangle {
	
	public float aOT(int  b , int h) {
		return  0.5f * b * h;
	}
	
	
	public int pOT(int s1, int s2, int b) {
		return s1+s2+b;
	}
}
