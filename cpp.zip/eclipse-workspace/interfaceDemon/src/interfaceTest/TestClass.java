package interfaceTest;


import interface1.Triangle;
import test.ShapeClass;
public class TestClass  {
	
	public static void main(String[] args) {
		ShapeClass t = new ShapeClass();
		System.out.println("Area of rectangle is :"+(t).aOR(5, 5));
		
	}
}
