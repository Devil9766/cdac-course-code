package interface1;
	
public interface Triangle {
	float aOT(int  b , int h) ;
	int pOT(int s1, int s2, int b) ;
}
