package interface1;

public interface Circle {
	default float aOC(int  radius) {
		return  3.142f*radius*radius;
				
	}
	default float pOC(int radius) {
		return 2 * 3.142f * radius;
		
	}
}
