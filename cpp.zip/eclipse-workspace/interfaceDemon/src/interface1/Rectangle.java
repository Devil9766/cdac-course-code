package interface1;

public interface Rectangle {
	default int aOR(int  l , int b) {
		return  l * b;
				
	}
	default int pOR(int l , int b) {
		return 2*(l+b);
		
	}
}
