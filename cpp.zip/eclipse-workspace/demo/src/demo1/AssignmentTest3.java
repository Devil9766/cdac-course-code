package demo1;

import java.util.Scanner;

public class AssignmentTest3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		
		do {
			System.out.println("1. Add new student\n2. delete by ID\n3. search by Id");
			System.out.println("4. Search by name\n5. display all\n6. modify name\n 7.Averrage of marks \n 8.exit\nChoice:");
			choice = sc.nextInt();
			switch(choice) {
			
			case 1:
			 AssignmentServices3.createStudent();
			 break;
			 
			 
			case 2: 
				studentInfo[] arr;
				System.out.println("Enter id you want to delete: ");
			int id = sc.nextInt();
			boolean ok = AssignmentServices3.deleteId(id);
			if(ok) {
				System.out.println("deleted successfully");
			}
			else {
				System.out.println("Id not found in list");
			}
			 break;
			
			case 3:
				System.out.println("enetr id for search");
				id=sc.nextInt();
				studentInfo p = AssignmentServices3.searchId(id);
				if(p!= null) {
					System.out.println(p);
				}else {
					System.out.println("Id not found in list");
				}
				break;
			
			case 4:
				sc.nextLine();
				System.out.println("Enter your name : ");
				String st = sc.nextLine();
				
				arr=AssignmentServices3.searchByName(st);
				if(arr!=null) {
					for(studentInfo i:arr) {
						if(i !=null) {
							System.out.println(i);
						}else {
							break;
						}
					}
				}else {
					System.out.println("Name not found");
				}
				break;
			case 5:
				
			arr=  AssignmentServices3.displayAll();
			if(arr != null) {
				for(studentInfo i:arr) {
					if(i != null) {
						System.out.println(i);
					}else {
						break;
					}
				}
			}
				break;
			
			case 6:
				System.out.println("enter id to change name.");
				id = sc.nextInt(); 
				sc.nextLine();
				System.out.println("enter new name.");
				String nn = sc.nextLine();
				
				ok = AssignmentServices3.changeName(id , nn);
				if(ok) {
					System.out.println("Name modified successfully.");
				}else {
					System.out.println("Student not found.");
				}
				break;
			case 7:
				System.out.println("Enter id of student to get avg marks: ");
				id=sc.nextInt();
				int avg = AssignmentServices3.getAvg(id);
				System.out.println("Avg of is : "+ avg);
				break;
			case 8 :
				System.out.println("thanks for visiting!!!!");
				sc.close();
				
			
			}
		}while(choice !=8);
		
	}
}
