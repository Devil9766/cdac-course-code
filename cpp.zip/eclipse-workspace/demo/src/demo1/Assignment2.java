package demo1;
import java.util.*;
public class Assignment2 {
	public static void main(String[] args) {
		int[][] arr = new int[3][4];
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		do {
			System.out.println("1. accept data\n2. display data\n3. add all numbers\n4. Add rowwise\n");
			System.out.println("5. add columnwise\n 6. find maximum\n 7. find minimum\n 8. find minimim row wise\n");
			System.out.println("9. find minimum column wise\n10. exit\nchoice: ");
			choice = sc.nextInt();
			switch (choice) {
				case 1:
					Assign2Services.acceptData(arr);
					break;
				case 2:
					Assign2Services.displayData(arr);
					break;
				case 3:
					int sum = Assign2Services.addAllNumbers(arr);
					System.out.println("Sum of all values: " + sum);
					break;
				case 4:
					int[] sumarr = Assign2Services.addrowwise(arr);
					for (int i = 0; i < sumarr.length; i++) {
						System.out.println("Sum of row " + i + ":  " + sumarr[i]);
					}
					break;
				case 5:
					sumarr = Assign2Services.addcolumnswise(arr);
					for (int i = 0; i < arr[0].length; i++) {
						System.out.println("Sum of row " + i + ":  " + sumarr[i]);
					}
					break;
				case 6 :
					int max = Assign2Services.findMax(arr);
					System.out.println("Max is "+max);
					break;
				case 7 :
					int min = Assign2Services.findMin(arr);
					System.out.println("Min is "+min);
					break;
					
				case 8:
					int [] minRow =  new int[arr.length];
					Assign2Services.findMinRow(arr , minRow);
					for(int i = 0; i< minRow.length; i++) {
						System.out.println("Min of row"+i+" is: " + minRow[i]);
					}
					break;
				case 9:
					int [] minCol =  new int[arr.length] ;
					Assign2Services.findMinCol(arr , minCol);
					for(int i = 0; i< minCol.length; i++) {
						System.out.println("Min of col"+i+" is: " + minCol[i]);
					}
					break;

				case 10:
					System.out.println("Thank you for visiting....");
					// System.gc();
					// System.exit(0);
				default:
					System.out.println("wrong choice....");
			}
		} while (choice != 10);

	}
}
