package demo1;
import java.util.*;

public class matrix {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int choice=0;
		System.out.println("Enter the size of matrix");
		int n = sc.nextInt();
		int[][] arr1 = new int[n][n]; 
		int[][] arr2 = new int[n][n]; 
		
		do {
			System.out.println("Enter your choice : \n 1.Create 2 matrix \n 2.Display matrix \n3. Addition \n 4.Multiplication \n 5. Symmetric \n 6. Exit \n");
			choice = sc.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Enter 1st matrix");
				arr1 = func.acceptMatrix(sc, n);
				System.out.println("Enter 2nd matrix");
				arr2 = func.acceptMatrix(sc, n);
				break;
			case 2 :
				System.out.println("Your 1st matrix: ");
				func.showMatrix(arr1);
				System.out.println("Your 2nd matrix: ");
				func.showMatrix(arr2);
				break;
			case 3:
				int [][] res = new int [n][n];
				func.addMatrix(arr1 ,arr2 , res);
				System.out.println("Addition of 2 matrix is: ");
				func.showMatrix(res);
				break;
			case 4:
				int [][] ans = new int [n][n];
				func.multiplyMatrix(arr1 ,arr2 , ans);
				System.out.println("Multiplication of 2 matrix is: ");
				func.showMatrix(ans);
				break;
				
			case 5:
				boolean symetric =func.symetricMatrix(arr1 , arr2) ;
				if(symetric == true) {
					System.out.println("matrix is symmetric");
				}else {
					System.out.println("matrix is not symmetric");
				}
				break;
				
			case 6 :
				System.out.println("Thanks for visiting");
				System.exit(0);
				
			
			}
		}while(choice != 6);
		sc.close();
	}
}
