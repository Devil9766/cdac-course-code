package demo1;

import java.util.Scanner;

public class func {
	public static int[][] acceptMatrix(Scanner sc , int n) {
		int[][] arr = new int[n][n];
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[0].length;j++) {
				System.out.print("Enter number for : "+i+","+j+" ------->");
				arr[i][j]=sc.nextInt();
			}
		}
		return arr;
	}
	
	public static void showMatrix(int [][] a) {
		for(int i = 0 ; i< a.length ; i++) {
			for(int j = 0 ; j< a[0].length ; j++) {
				System.out.print(a[i][j] + "\t");
			}
			System.out.println();
		}
	}
	
	public static void addMatrix(int a[][] , int b [][] , int [][] res){
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a[0].length;j++) {
				res[i][j] = a[i][j] + b[i][j];
			}
		}
	}
	
	
	public static void multiplyMatrix(int a[][] , int b [][] , int [][] res){
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a[0].length;j++) {
				res[i][j]=a[i][j]*b[i][j];
			}
			
		}
	}
	

	
	
	public static boolean symetricMatrix(int a[][] , int b [][] ){
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a[0].length;j++) {
				if(a[i][j] != b[i][j]) {
					return false;
				}
			}
		}
		return true;
	}
}
