package demo1;
import java.text.SimpleDateFormat;
import java.util.*;
public class studentInfo {
	private int rollNo ;
	private String name;
	private String mobileNo;
	private Date bdate;
	private int m1;
	private int m2;
	private int m3;
	
	
	public studentInfo(){
		this.rollNo = 0;
		this.name = null;
		this.mobileNo = null;
		this.bdate = null;
		this.m1=0;
		this.m2=0;
		this.m3=0;
	}
	
	public studentInfo(int r , String name , String mbNo, Date bdate, int m1,int m2,int m3){
		this.rollNo = r;
		this.name = name;
		this.mobileNo = mbNo;
		this.bdate = bdate;
		this.m1=m1;
		this.m2=m2;
		this.m3=m3;
	}
	
	public void setSname(String name) {
		this.name=name;
	}
	
	public void setMobile(String mob) {
		this.mobileNo =mob;
	}
	
	public void setBdate(Date dt1) {
		this.bdate = dt1;
	}
	
	//getter methods
	public int getSid(){
		return rollNo;
	}
	
	public String getSname() {
		return name;
	}
	
	public String getMobile() {
		return mobileNo;
	}
	public Date getBdate() {
		return bdate;
	}
	
	public int getM1(){
		return m1;
	}
	public void setM1(){
		this.m1= m1;
	}
	public int getM2(){
		return m2;
	}
	public void setM2(){
		this.m2= m2;
	}

	public int getM3(){
		return m3;
	}
	public void setM3(){
		this.m3= m3;
	}

	
	
	public String toString() {
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		String dt=sdf.format(bdate);
		return "Id : " +this.rollNo+"\nName : "+name+"\nMobile: "+mobileNo+"\nBDate: "+dt+"\n m1: "+m1+"\n m2: "+m2+"\n m3: "+m3;
	}
}
