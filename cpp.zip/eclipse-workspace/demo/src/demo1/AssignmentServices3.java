package demo1;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import java.text.ParseException;
public class AssignmentServices3 {
	private static studentInfo[] s = new studentInfo[10];
	private static int cnt = 2;
	private static Date dt;
	static {
		s[0]=new studentInfo(12,"Rajan","2222",new Date(2000,04,27),50,60,70);
		s[1]=new studentInfo(14,"Rajana","2748",new Date(2007,06,20),70,80,90);
	}
	public static void createStudent() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter your roll number");
		int roll = sc.nextInt();
		sc.nextLine();
		System.out.println("enter your name");
		String name = sc.nextLine();
		System.out.println("Enter your number");
		String num = sc.next();
		System.out.println("enter your birth date");
		String bdate = sc.next();
		System.out.println("enter your m1 marks : ");
		int m1=sc.nextInt();
		System.out.println("enter your m2 marks : ");
		int m2=sc.nextInt();
		System.out.println("enter your m3 marks : ");
		int m3=sc.nextInt();
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		
		try {
			dt=sdf.parse(bdate);
			
		}catch(ParseException e) {
			e.printStackTrace();
		}
		s[cnt]=new studentInfo(roll,name,num,dt,m1,m2,m3);
		cnt++;
		
	}
	public static studentInfo[] displayAll() {
		return s;
	}
	
	public static boolean deleteId(int id) {
		for(int i = 0 ; i < cnt; i++) {
			if(s[i].getSid() == id) {
				for( int j = i ; j< cnt; j++) {
					s[j] = s[j+1];
				}
				cnt--;
				return true;
			}
		}
		return false;
	}
	
	public static studentInfo searchId(int id) {
		for(int i = 0 ; i<cnt ; i++) {
			if(s[i]!= null) {
				if(s[i].getSid() == id) {
					return s[i];
			}
		}else {
			return null;
		}
	}
		return null;
	}
	public static studentInfo[] searchByName(String st) {
		int count=0;
		studentInfo[] s1 = new studentInfo[cnt];
	    for(int i=0;i<cnt;i++) {
	    	if(s[i]!= null) {
	    		if(s[i].getSname().equals(st)) {
	    			s1[count]=s[i];
	    			count++;
	    		}
	    	}else {
	    		break;
	    	}
	    }
	    return s1;
	}
	
	
	public static boolean changeName(int id , String nn) {
		for(int i = 0; i< cnt; i++) {
			if(s[i].getSid() == id) {
				s[i].setSname(nn);
				return true;
			}
			
		}return false;
	}
	
	public static int getAvg(int id) {
		int avg=0;
		for(int i=0;i<cnt;i++) {
			if(s[i].getSid()==id) {
				avg=(s[i].getM1()+s[i].getM2()+s[i].getM3())/3;
			}
		}
		return avg;
		
	}
	
}
