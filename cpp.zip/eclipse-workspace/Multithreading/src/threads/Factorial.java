package threads;

import beans.MathFunctions;

public class Factorial extends Thread {
	private MathFunctions ob;
	int n;
	public Factorial(MathFunctions ob, int n) {
		super();
		this.ob = ob;
		this.n = n;
	}
	public void run() {
		int ans= ob.factorial(n);
		System.out.println("Factorial of "+n+ "is :" +ans);
	}
	
}
