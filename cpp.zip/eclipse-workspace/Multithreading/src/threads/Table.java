package threads;

import java.awt.print.Printable;

import beans.MathFunctions;

public class Table extends Thread{
	private MathFunctions ob;
	private int n;
	public Table(MathFunctions ob, int n) {
		super();
		this.ob=ob;
		this.n = n;
	}
	
	public void run() {
		ob.printTable(n);
		
	}
	
	
	
}
