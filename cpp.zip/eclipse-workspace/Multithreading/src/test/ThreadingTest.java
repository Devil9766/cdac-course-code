package test;

import beans.MathFunctions;
import threads.Factorial;
import threads.Table;

public class ThreadingTest {
	public static void main(String[] args) {
		MathFunctions ob= new MathFunctions();
		Table t1 = new Table(ob,  5);
		Table t2=new Table(ob,  8);
		Factorial f1 = new Factorial(ob, 8);
		Factorial f2 = new Factorial(ob, 8);
		

		t1.start();
		t2.start();
		f1.start();
		f2.start();
		
		
		try {
			t1.join();
			t2.join();
			f1.join(300);
			f2.join(300);
		} catch (Exception e) {
			// TODO: handle exception
		}
		System.out.println("rest of the main function");
	}
}


