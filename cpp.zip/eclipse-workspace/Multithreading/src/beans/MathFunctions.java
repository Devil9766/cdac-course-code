package beans;

public class MathFunctions {
	 public void printTable(int n) {
		for(int i=1;i<=10;i++) {
			System.out.println(n+"*"+i+"="+(i*n));
			try {
				Thread.sleep(500);
			}catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	synchronized public int factorial(int n) {
		int fact = 1;
		for (int i = 1 ; i<= n ; i++) {
			fact *= i;
		}
		return fact;
	}
	
}
