package com.demo.test;

import java.util.Arrays;

public class ArrayService {

	public static void BubbleSort(int[] arr) {
		for(int i = 0 ; i< arr.length ; i++) {
			for(int j=1;j<arr.length-i;j++) {
			 if(arr[j-1]>arr[j]) {
				 int temp=arr[j-1];
				 arr[j-1]=arr[j];
				 arr[j]=temp;
			 }
			 
			}
		}
		 
	}

	

	public static void quickSort(int[] arr, int low, int high) {
		int i,j = 0,pivot = 0,temp;
		if(low<high) {
			i=low;
			j=high;
			pivot=low;
			
			while(i<j) {
				while(arr[i]<=arr[pivot] && i<high) {
					i++;
				}
				while(arr[j]>arr[pivot]  && j>pivot) {
					j--;
				}
				if(i<j) {
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		
		temp=arr[pivot];
		arr[pivot]=arr[j];
		arr[j]=temp;
		quickSort(arr, low, j-1);
		quickSort(arr, j+1, high);
		
		}
		
	}
	
	

	public static void insertionSort1( int[] arr) {
		int temp = 0;
		for(int i = 1; i<arr.length; i++){
			int j=i-1;
			temp=arr[i];
			while(j>=0 && arr[j]>temp){
				arr[j+1]=arr[j];
				j--;
			}
			arr[j+1]=temp;
		}
	}


	

	public static void mergeSort(int[] arr,int low,int high) {
		if(low < high) {
			int mid = (low+high)/2;
			mergeSort(arr,low,mid);
			mergeSort(arr,mid+1,high);
			merge(arr, low, mid, high);
		}
		
		}

	private static void merge(int[] arr, int low, int mid, int high) {
		int i,j,k;
		
		int n1 = mid-low+1;
		int n2 = high -mid;
		
		int[] left = new int[n1];
		int[] right = new int[n2];
		
		
		i=0;
		for(int a = low ; a<=mid; a++) {
			left[i] = arr[a];
			i++;
		}
		j=0;
		for(int b = mid+1 ; b<=high ; b++ ) {
			right[j] = arr[b];
			j++;
		}
		
		i = 0;
		j=0;
		k= low;
		
		while(i<n1 && j<n2) {
			if(left[i] < right[j] ){
				arr[k] = left[i];
				i++;
				k++;
			}else {
				arr[k] = right[j];
				j++; 
				k++;
			}
		
	}
		
		
		while(i< n1) {
			arr[k] = left[i];
			i++; 
			k++;
			
		}
		while(j<n2) {
			arr[k] = right[j];
			k++;
			j++;
		}
		
		
	}



	public static void selectionSort(int[] arr) {
		for(int i=0;i<arr.length-1;i++) {
			int min_idx=i;
			for(int j=i+1;j<arr.length;j++) {
				if(arr[j]<arr[min_idx]) {
					min_idx=j;
				}
			}
			int temp=arr[i];
			arr[i]=arr[min_idx];
			arr[min_idx]=temp;
			
		}
	}
	
	public static void CountingSort(int [] arr) {
		int max =0;
		for(int i = 0; i< arr.length; i++) {
				max = Math.max(max, arr[i]);
			}
		
		int[] count = new int[max+1];
		for(int num : arr) {
				count[num]++;
		}
		int[] cSum = new int[max+1] ;
				int cnt = 1;
//		System.out.println(Arrays.toString(count));
		cSum[0] = count[0];
		for(int i=1;i<cSum.length;i++) {
			cSum[cnt]=cSum[cnt-1]+count[i];
			cnt++;
		}
		int[ ] sorted = new int[arr.length];
		for(int k = 0 ; k <arr.length; k++) {
			sorted[cSum[arr[k]] -1] = arr[k];
			 cSum[arr[k]]--;
			
		}
		

		System.out.println(Arrays.toString(sorted));
		}
		
		
		
	}
	

