package com.demo.test;

import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Stream;

public class SortingTest {
	public static void main(String[] args) {
		int[] arr= {12,10,23,24,10,15,5,18,5,24,5,8,2,14,23};
//		int[] arr= {23,1,2,56,34,2,7,8,9};
		Scanner sc = new Scanner(System.in);
//		System.out.println("enter num to search: ");
//  	Bubble Sort
//		int num = sc.nextInt();
//		 ArrayService.BubbleSort(arr);
//		System.out.println( Arrays.toString(arr));
//		int low=0;
//		int high=arr.length-1;
//		int[] arr1=new int[5];
//		System.out.println(Arrays.toString(arr1));
//		System.out.println("sorted using quik sort");
//		ArrayService.quickSort(arr,low,high);
//		System.out.println(Arrays.toString(arr));
//		ArrayService.insertionSort1(arr);
//		System.out.print("sorted using insertion sort: " + Arrays.toString(arr));
		
		
//		ArrayService.mergeSort(arr,0,arr.length-1);
//		System.out.print("sorted using merge sort: " + Arrays.toString(arr))
		
//		ArrayService.selectionSort(arr);
//		System.out.println("sorted using selection sort : "+Arrays.toString(arr));
		ArrayService.CountingSort(arr);
		
//		System.out.println(Arrays.toString(arr));
		
		
	}
}
