package services;

public class FunctionService {

	

	public static int binarySearch(int l, int h, int num, int[] arr) {
		
		if(l<=h) {
			int mid = (l+h)/2;
			if(arr[mid] == num) {
				return mid;
			}else if(num > arr[mid]) {
				return binarySearch(mid+1, h, num, arr);
			}else {
				return binarySearch(l, mid-1, num, arr);
			}
		}return -1;
	}

	public static int linearSearch(int num, int[] arr) {
		for(int i= 0; i< arr.length;i++) {
			if(num == arr[i]){
				return i;
			}
		}return -1;
	}
	public static boolean isPrime(int n) {
		for(int i=2;i<=n/2;i++) {
			if(n%i==0) {
				return false;
			}
		}
		return true;
	}
	public static int primeSum(int[] arr) {
		int sum=0;
		for(int i=0;i<arr.length;i++) {
			if(isPrime(arr[i])) {
				sum+=arr[i];
			}
		}
		return sum;
	}

	public static int secondMax(int[] arr1) {
		int max=arr1[0],prev=0;
		for(int i=0;i<arr1.length;i++) {
			if(max<arr1[i]) {
				prev=max;
				max=arr1[i];
			}
			if(arr1[i]<max && arr1[i]>prev) {
				prev=arr1[i];
			}
		}
		return prev;
	}

	public static int recurSum(int[] arr, int length) {
		if(length < 0) {
			return 0;
		}
		return arr[length] + recurSum(arr, length-1);
	}

}
