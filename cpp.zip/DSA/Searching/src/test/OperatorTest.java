package test;

import services.FunctionService;

public class OperatorTest {
	public static void main(String[] args) {
	int arr[]= {1,2,3,4,5,6,11,8,13,17};
	int arr1[]= {4,6,7,3,4,6,8,9,5,11};
	int num=FunctionService.secondMax(arr1);
	System.out.println("Second max number is : "+num);
//	int sum= FunctionService.primeSum(arr);
//	System.out.println("Prime sum is : "+sum);
	int recurSum = FunctionService.recurSum(arr, arr.length-1);
	System.out.println("recursice sum of arr is: " + recurSum);
	
	
}
}
