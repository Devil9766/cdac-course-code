package test;

import java.util.Scanner;

import services.FunctionService;

public class Test {
	public static void main(String[] args) {
		int arr[]= {1,2,3,4,6,7,9, 14};
		Scanner sc=new Scanner(System.in);
		int l = 0;
		int h= arr.length-1;
		int choice = 0;
		String ans=null;
		do {
			
			System.out.println("choose search method: \n 1.Binary Search \n2.Linear Search \n 3.exit");
			choice = sc.nextInt();
			switch(choice) {
			
			case 1->{
				System.out.println("enter number to search");
				int num = sc.nextInt();
			int pos=FunctionService.binarySearch(l, h, num, arr);
			if(pos != -1) {
				System.out.println("number is at position : "+pos);
			}else {
				System.out.println("number not found.");
			}
			
			}
			case 2 ->{
				System.out.println("enter number to search");
				int num = sc.nextInt();
				int pos = FunctionService.linearSearch(num , arr);
						if(pos != -1) {
							System.out.println("number is at position : "+pos);
						}else {
							System.out.println("number not found.");
						}
						
			}
			case 3 ->{
				System.out.println("thanks for visiting.......");
				sc.close();
			}
			}
			
			
		}while(choice!=3);
		
		
	}
}
