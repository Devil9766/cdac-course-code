package test;

import java.util.Scanner;

import services.LinkedListServices;

public class LinkedListTest {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		LinkedListServices linkedListServices = new LinkedListServices();
		linkedListServices.addNode(6);
		linkedListServices.addNode(5);
		linkedListServices.addNode(4);
		linkedListServices.addNode(9);
		linkedListServices.addNode(2);
		
//		linkedListServices.display();
//		System.out.println("tell position to add: ");
//		int pos = sc.nextInt();
//		linkedListServices.addByPosition(3, 6);
//		linkedListServices.display();
		
//		linkedListServices.deleteByPosition(4);
		
		
//		linkedListServices.display();
//		System.out.println();
//		int pos = linkedListServices.searchByValue(66);
//		if(pos==-1) {
//			System.out.println("Number not found");
//		}else
//			System.out.println(pos);
		
//		linkedListServices.deleteByValue(2);
		
		
		linkedListServices.addByValue(10);
		linkedListServices.display();

	}
}
