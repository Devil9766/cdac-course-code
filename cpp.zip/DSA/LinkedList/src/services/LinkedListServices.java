package services;

public class LinkedListServices {
	 class Node{
		 int data;
		Node next;
		public Node(int data) {
			super();
			this.data = data;
			this.next=null;
		}
	}
	 Node head;
	 public LinkedListServices() {
		 head=null;
	 }
	public  void addNode(int val) {
		Node newNode=new Node(val);
		if(head==null) {
			head = newNode;
		}else {
			Node temp=head;
			while(temp.next!=null) {
				temp=temp.next;	
			}
			temp.next=newNode;
			
			
		}
		
		
		
	}
	public void display() {
		if(head==null) {
			System.out.println("List is empty");
		}else {
			Node temp=head;
			while(temp!=null) {
				System.out.print(temp.data+"-->");
				temp=temp.next;
			}
		}
		
	}
	public  void addByPosition(int pos, int val) {
		int count = 1;
		Node temp = head;
		Node newNode = new Node(val);
		if(head == null) {
			System.out.println("list is empty");
		}else{
			while (temp!= null && count < pos-1) {
				temp = temp.next;
				count++;
			}
			
				newNode.next = temp.next;
				temp.next =newNode;
			
		}
	}
	
	
	public  void deleteByPosition(int pos) {
		int count = 1;
		Node temp = head;
		Node prev = null;
		if(head == null) {
			System.out.println("list is empty");
		}else{
			while (temp!= null && count < pos) {
				prev = temp;
				temp = temp.next;
				count++;
			}
			
				prev.next = temp.next;
				temp.next = null;
				temp=null;
			
		}
	}
	public int searchByValue(int val) {
		
		if(head==null) {
			System.out.println("List is empty");
		}else {
			Node temp=head;
			int cnt=1;
			while(temp!=null) {
				if(temp.data==val) {
					return cnt;
				}
				temp=temp.next;
				cnt++;
			}
		}
		return -1;
	}
	public void deleteByValue(int val) {
		if(head==null) {
			System.out.println("List is empty");
		}else {
			Node temp=head;
			Node prev=null;
			if(head.data==val ) {
				head=temp.next;
				temp.next=null;
				temp=null;
			}else {
			while(temp!=null && temp.data!=val) {
				prev=temp;
				temp=temp.next;
			}
			prev.next=temp.next;
			temp.next=null;
		}
		}
		}
	
	public void addByValue(int val) {
		if(head==null) {
			System.out.println("List is empty");
		}else {
			Node  newNode = new Node(val); 
			Node temp=head;
			Node prev=null;
			if(temp.data > val) {
				newNode.next = head;
				head = newNode;
			}else {
			while(temp!=null && temp.data<val) {
				prev=temp;
				temp=temp.next;

			}
			newNode.next = temp;
			prev.next=newNode;
			
			}
			
				
		
		}
			}
		
		
		
		
		
		    
		
		
		
		
	}
	
	
	
	
	
	

